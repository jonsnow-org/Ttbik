"""High-level public API facade for the ModelScope Hub SDK.

:class:`HubApi` is the **only** entry point users should construct. It composes
the low-level :class:`OpenAPIClient`, :class:`LegacyClient`,
:class:`DownloadManager`, :class:`UploadManager` and the cache helpers into a
unified, OpenAPI-first surface.

Design principles
-----------------
* **OpenAPI-first** — every operation that has an OpenAPI counterpart goes
  through :mod:`._openapi`. Legacy endpoints are used only as a transparent
  fallback when no OpenAPI equivalent exists.
* **Unified repo pattern** — every repository operation accepts a
  ``repo_type`` parameter; there are no type-specific methods like
  ``create_model`` or ``get_dataset``.
* **Transparent fallback** — callers do not need to know which path served
  their request.
* **Lazy clients** — the underlying HTTP clients are instantiated on demand
  so that ``HubApi()`` never fails just because no token is present.
* **SOLID** — :class:`HubApi` only routes and orchestrates; concrete network
  logic lives in the injected dependencies.
"""

from __future__ import annotations

import fnmatch
import time
from collections.abc import Callable, Iterable, Mapping
from pathlib import Path
from typing import Any, BinaryIO, TypeAlias, TypeVar
from urllib.parse import urlparse

from requests.cookies import RequestsCookieJar

from ._cache_manager import _resolve_verification_root
from ._cache_manager import clear_cache as _clear_cache
from ._cache_manager import scan_cache as _scan_cache
from ._cache_manager import verify_cache as _verify_cache
from ._download import DownloadManager, ProgressCallback
from ._legacy_api import LegacyClient
from ._openapi import OpenAPIClient
from ._upload import UploadManager
from .agent_idp import sign_agent_token_request
from .config import HubConfig, get_default_config
from .constants import (
    DEFAULT_ENDPOINT,
    OPENAPI_CREATE_DATASET_FIELDS,
    OPENAPI_CREATE_MODEL_FIELDS,
    OPENAPI_MODEL_LICENSES,
    OPENAPI_VERSION_NAME_MAX_LENGTH,
    WEIGHT_FILE_SUFFIXES,
    AigcModelType,
    DatasetCategory,
    ModelCategory,
    RepoType,
    RepoVisibility,
    StrEnum,
    StudioVisibility,
    Visibility,
)
from .errors import (
    AlreadyExistsError,
    AuthenticationError,
    HubError,
    InvalidParameter,
    NotExistError,
    NotSupportedError,
    PermissionDeniedError,
    ServerError,
    is_repo_exists_error,
)
from .types import (
    AgentIdConfiguration,
    AgentIdentity,
    AgentIdentitySummary,
    AgentJWK,
    AgentToken,
    AgentTokenRecord,
    CacheInfo,
    CacheVerification,
    DownloadReport,
    DownloadRetryPolicy,
    FileInfo,
    PagedResult,
    RepoInfo,
    UserInfo,
)
from .utils import build_user_agent
from .utils.logger import get_logger

__all__ = ["HubApi"]

logger = get_logger("api")

RepoTypeLike: TypeAlias = "str | RepoType"

# Any of the string enums the category payloads validate against.
_StrEnumT = TypeVar("_StrEnumT", bound=StrEnum)


# Routing tables — declarative dispatch keeps :class:`HubApi` free of long
# if/elif chains and makes adding new repo types a one-line change.
_CREATABLE_TYPES: frozenset[RepoType] = frozenset({RepoType.MODEL, RepoType.DATASET, RepoType.STUDIO, RepoType.SKILL})
_OPENAPI_CREATE_TYPES: frozenset[RepoType] = frozenset(
    {RepoType.MODEL, RepoType.DATASET, RepoType.STUDIO, RepoType.SKILL}
)
# Repo kinds whose OpenAPI create endpoint can be bypassed for inputs it cannot
# express. Studio and Skill have no legacy create endpoint, so they are absent.
_LEGACY_CREATE_FALLBACK_TYPES: frozenset[RepoType] = frozenset({RepoType.MODEL, RepoType.DATASET})
_OPENAPI_DETAIL_TYPES: frozenset[RepoType] = frozenset(
    {RepoType.MODEL, RepoType.DATASET, RepoType.STUDIO, RepoType.SKILL}
)
# Mapping of common license display names to their SPDX identifiers. The Hub
# backend rejects display names like ``"Apache License 2.0"`` — we translate
# them transparently while passing unknown values (already SPDX) through.
_LICENSE_DISPLAY_TO_SPDX: dict[str, str] = {
    "Apache License 2.0": "apache-2.0",
    "MIT License": "mit",
    "GPL-2.0": "gpl-2.0",
    "GPL-3.0": "gpl-3.0",
    "LGPL-2.1": "lgpl-2.1",
    "LGPL-3.0": "lgpl-3.0",
    "AFL-3.0": "afl-3.0",
    "ECL-2.0": "ecl-2.0",
    "BSD-2-Clause": "bsd-2-clause",
    "BSD-3-Clause": "bsd-3-clause",
    "CC-BY-4.0": "cc-by-4.0",
    "CC-BY-SA-4.0": "cc-by-sa-4.0",
    "CC-BY-NC-4.0": "cc-by-nc-4.0",
    "CC0-1.0": "cc0-1.0",
    "Unlicense": "unlicense",
}


# Studio payload keys the SDK once renamed on the way out. The specification
# spells the field ``cover_image``, so the old outbound rename silently dropped
# every cover image the caller supplied; the mapping now runs the other way, to
# normalise callers still passing the camelCase spelling.
_STUDIO_FIELD_ALIASES: dict[str, str] = {
    "coverImage": "cover_image",
}

# Reserved fields that are controlled by create_repo method parameters.
# These MUST NOT be overridden via extra kwargs to avoid silent conflicts.
_RESERVED_EXTRA_FIELDS: frozenset[str] = frozenset({"Path", "Owner", "Name"})

# Settings the model/dataset settings endpoints report but cannot change.
# ``login_required`` appears in a dataset's detail payload, yet no request
# schema accepts it, so it can only be changed through the web UI.
_UNSETTABLE_FIELDS: frozenset[str] = frozenset({"login_required"})


def _unwrap_list(payload: Any, keys: tuple[str, ...]) -> list[dict]:
    """Pull a list out of an OpenAPI payload, tolerating either shape.

    Some endpoints answer with the collection at the top level and others nest it
    under a resource-specific key, so both are accepted rather than assuming one.
    """
    if isinstance(payload, list):
        return payload
    if isinstance(payload, dict):
        for key in keys:
            if isinstance(payload.get(key), list):
                return payload[key]
    return []


def _normalise_studio_fields(fields: Mapping[str, Any]) -> dict[str, Any]:
    """Map legacy Studio field spellings onto the ones the endpoint accepts.

    Also expands ``visibility`` into the ``private`` companion flag so a caller
    who reaches the Studio endpoints through ``**settings`` gets the same
    treatment as one who passes ``visibility=`` explicitly.
    """
    normalised = {_STUDIO_FIELD_ALIASES.get(key, key): value for key, value in fields.items()}
    studio_visibility = StudioVisibility.parse(normalised.get("visibility"))
    if studio_visibility is not None:
        normalised["visibility"] = studio_visibility.value
        normalised.setdefault("private", studio_visibility is StudioVisibility.PRIVATE)
    return normalised


class HubApi:
    """Unified client for ModelScope Hub operations.

    Provides a high-level interface for repository management, file
    operations, deployment, secret management and local caching. All
    repo-type-specific operations use a unified ``repo_type`` parameter
    following the OpenAPI-First design — there are no type-specific
    methods like ``create_model`` or ``get_dataset``.

    Internally the class composes :class:`OpenAPIClient`,
    :class:`LegacyClient`, :class:`DownloadManager`, :class:`UploadManager`
    and the cache helpers. HTTP clients are instantiated lazily, so
    ``HubApi()`` never fails just because no token is present.

    Parameters
    ----------
    config : HubConfig or None, optional
        Pre-built configuration. When omitted, the process-wide default
        from :func:`get_default_config` is used (which reads the
        ``MODELSCOPE_API_TOKEN`` env var and the local config file).
    endpoint : str or None, optional
        Override the API endpoint. Takes precedence over ``config.endpoint``.
        Defaults to ``https://modelscope.cn``.
    token : str or None, optional
        Override the API token. Takes precedence over ``config.token``.
    user_agent : dict, str or None, optional
        Application or channel information appended to the SDK UA and propagated
        to OpenAPI, legacy, probe and download requests. Must not contain credentials.
    download_total_timeout : float or None, optional
        Per-file download time budget in seconds, covering lock waits, probes,
        transfers, retries and validation. ``None`` uses
        ``MODELSCOPE_DOWNLOAD_TOTAL_TIMEOUT``; ``0`` or less imposes no overall
        limit, leaving idle timeouts, the low-speed watchdog and bounded
        retries as the only stop conditions.

    Examples
    --------
    >>> from modelscope_hub import HubApi
    >>> api = HubApi(token="ms-xxxxxxxx")
    >>> user = api.whoami()
    >>> user.username
    'alice'

    Create and manage repositories:

    >>> api.create_repo("alice/my-model", repo_type="model", visibility="private")
    >>> api.upload_file("alice/my-model", "model", "./weights.bin", "weights.bin")
    >>> path = api.download_file("alice/my-model", "model", "weights.bin")
    """

    def __init__(
        self,
        config: HubConfig | None = None,
        *,
        endpoint: str | None = None,
        token: str | None = None,
        user_agent: dict | str | None = None,
        download_total_timeout: float | None = None,
    ) -> None:
        self._user_agent_extra = dict(user_agent) if isinstance(user_agent, dict) else user_agent
        self._download_total_timeout = download_total_timeout
        base = config or get_default_config()
        if config is None and (endpoint is not None or token is not None):
            from dataclasses import replace

            was_overridden = base._endpoint_overridden
            base = replace(base)
            # replace() re-runs __post_init__ which sees the inherited
            # endpoint string as "explicit" and sets _endpoint_overridden.
            # Restore the original state so resolve_endpoint_for_read works.
            base._endpoint_overridden = was_overridden
        self._config = base
        if endpoint is not None:
            self._config.endpoint = HubConfig.normalize_endpoint(endpoint)
            self._config._endpoint_overridden = True
        if token is not None:
            self._config.token = token
            self._config._token_overridden = True

        self._openapi: OpenAPIClient | None = None
        self._legacy: LegacyClient | None = None
        self._downloader: DownloadManager | None = None
        self._uploader: UploadManager | None = None

    # ==================================================================
    # Lazy client accessors
    # ==================================================================
    @property
    def openapi(self) -> OpenAPIClient:
        """Lazily-constructed OpenAPI client."""
        if self._openapi is None:
            self._openapi = OpenAPIClient(self._config, user_agent=self._user_agent_extra)
        return self._openapi

    @property
    def legacy(self) -> LegacyClient:
        """Lazily-constructed legacy ``/api/v1`` client."""
        if self._legacy is None:
            self._legacy = LegacyClient(
                token=self._config.token,
                endpoint=self._config.endpoint or DEFAULT_ENDPOINT,
                user_agent=build_user_agent(config=self._config, extra=self._user_agent_extra),
            )
        elif self._legacy.token != self._config.token:
            # Clears propagate as well as changes: a cached client left holding a
            # revoked token would keep authenticating with it.
            self._legacy.token = self._config.token
        return self._legacy

    @property
    def downloader(self) -> DownloadManager:
        """Lazily-constructed :class:`DownloadManager`."""
        if self._downloader is None:
            self._downloader = DownloadManager(
                self.legacy,
                self._config,
                user_agent=self._user_agent_extra,
                total_timeout=self._download_total_timeout,
            )
        return self._downloader

    @property
    def uploader(self) -> UploadManager:
        """Lazily-constructed :class:`UploadManager`.

        The OpenAPI client is injected so small files (≤ 5 MiB) flow through
        ``POST /files/upload`` instead of the legacy commit endpoint.
        """
        if self._uploader is None:
            self._uploader = UploadManager(
                self.legacy,
                self._config,
                self.openapi,
                create_repo_fn=self._create_repo_exist_ok,
            )
        return self._uploader

    # ==================================================================
    # Static helpers
    # ==================================================================
    @staticmethod
    def _parse_repo_id(repo_id: str) -> tuple[str, str]:
        """Split a canonical ``owner/name`` identifier into its two halves."""
        if not repo_id or "/" not in repo_id:
            raise InvalidParameter(f"repo_id {repo_id!r} should be in format of 'owner/name'.")
        owner, _, name = repo_id.partition("/")
        if not owner or not name:
            raise InvalidParameter(
                f"repo_id {repo_id!r} should be in format of 'owner/name': owner and name must both be non-empty."
            )
        return owner, name

    def _create_repo_exist_ok(self, repo_id: str, repo_type: str) -> None:
        """Auto-create the repo if it doesn't exist, silently ignore if it does."""
        try:
            self.create_repo(repo_id, repo_type)
        except HubError:
            pass

    @staticmethod
    def _normalize_repo_type(repo_type: RepoTypeLike) -> RepoType:
        """Coerce a ``str`` or :class:`RepoType` value to a :class:`RepoType`."""
        if isinstance(repo_type, RepoType):
            return repo_type
        try:
            return RepoType(str(repo_type).lower())
        except ValueError as exc:
            allowed = ", ".join(t.value for t in RepoType)
            raise InvalidParameter(f"Unknown repo_type {repo_type!r}. Expected one of: {allowed}.") from exc

    @staticmethod
    def _normalize_visibility(visibility: int | str | Visibility | None) -> int | None:
        """Normalise visibility input to its integer wire encoding."""
        if visibility is None:
            return None
        if isinstance(visibility, Visibility):
            return int(visibility)
        if isinstance(visibility, int):
            return visibility
        return int(Visibility.from_label(str(visibility)))

    _PAGED_ITEM_KEYS = (
        "items",
        "list",
        "data",
        "results",
        "models",
        "datasets",
        "skills",
        "studios",
        "variables",
        "servers",
        "mcp_server_list",
        "Models",
        "Datasets",
        "Skills",
        "Servers",
    )
    _PAGED_META_KEYS = frozenset(
        {
            "total_count",
            "total",
            "page_number",
            "page",
            "page_size",
            "size",
            "TotalCount",
            "Total",
            "PageNumber",
            "PageSize",
        }
    )

    @staticmethod
    def _extract_paged(payload: Any) -> tuple[list[Any], int, int, int]:
        """Decode a paginated OpenAPI response into ``(items, total, page, size)``.

        The ModelScope API returns item arrays under type-specific keys
        (``models``, ``datasets``, ``skills``, ``servers``). This method
        checks known keys first, then falls back to the first list-valued
        key that is not pagination metadata.
        """
        if isinstance(payload, list):
            return payload, len(payload), 1, len(payload)
        if not isinstance(payload, dict):
            return [], 0, 1, 0

        items: list[Any] = []
        for key in HubApi._PAGED_ITEM_KEYS:
            if isinstance(payload.get(key), list):
                items = payload[key]
                break
        else:
            for key, value in payload.items():
                if isinstance(value, list) and key not in HubApi._PAGED_META_KEYS:
                    items = value
                    break

        def _first(keys: tuple[str, ...], default: int) -> int:
            for k in keys:
                v = payload.get(k)
                if v is not None:
                    return int(v)
            return default

        total = _first(("total_count", "TotalCount", "total"), len(items))
        page = _first(("page_number", "PageNumber", "page"), 1)
        size = _first(("page_size", "PageSize", "size"), len(items))
        return items, total, page, size

    @staticmethod
    def _repo_info_from_payload(
        data: Mapping[str, Any] | None,
        repo_type: RepoType,
        *,
        owner_hint: str | None = None,
        name_hint: str | None = None,
    ) -> RepoInfo:
        """Build a :class:`RepoInfo` from an arbitrary API payload.

        The legacy and OpenAPI surfaces use different field-naming conventions
        (PascalCase vs snake_case). This helper normalises both into the
        SDK's canonical dataclass.
        """
        data = dict(data or {})
        # PascalCase → snake_case shims for legacy responses.
        normalised: dict[str, Any] = {}
        aliases = {
            "Id": "id",
            "Path": "owner",
            "Name": "name",
            "Owner": "owner",
            "Visibility": "visibility",
            "License": "license",
            "Description": "description",
            "Downloads": "downloads",
            "Likes": "likes",
            "CreatedAt": "created_at",
            "UpdatedAt": "last_modified",
            "LastModified": "last_modified",
            "last_modified": "last_modified",
            "updated_at": "last_modified",
            "Tags": "tags",
        }
        for key, value in data.items():
            normalised[aliases.get(key, key)] = value

        # Normalize native access modes to the historical SDK enum. The server
        # reports private=false for gated repos, so the private flag alone is insufficient.
        raw_visibility = normalised.get("visibility")
        if isinstance(raw_visibility, str):
            # Two string encodings arrive here. Studio payloads use
            # ``public``/``protected``/``private``; model and dataset detail
            # payloads use ``public``/``private``/``gated``. ``gated`` must not
            # fall through as a raw string: ``visibility`` is typed as the
            # integer :class:`Visibility`, and leaking a ``str`` would break
            # ``.label``, ``int()`` and equality against the enum -- including
            # in the compat dict, which the legacy SDK reads as an integer.
            #
            # A gated repository maps to PRIVATE because that is what it is on
            # the legacy wire (``Visibility=PRIVATE`` plus ``ProtectedMode=1``);
            # the approval mode itself is carried separately by ``gated`` and
            # ``gated_mode``. The server reports ``private: false`` for gated
            # repos, so without this branch they would be reported as PUBLIC.
            repo_visibility = RepoVisibility.parse(raw_visibility)
            studio_visibility = StudioVisibility.parse(raw_visibility)
            if repo_visibility is RepoVisibility.GATED:
                normalised["visibility"] = Visibility.PRIVATE
                normalised.setdefault("gated", True)
            elif studio_visibility is StudioVisibility.PUBLIC:
                normalised["visibility"] = Visibility.PUBLIC
            elif studio_visibility is StudioVisibility.PRIVATE:
                normalised["visibility"] = Visibility.PRIVATE
            elif studio_visibility is not None:
                # ``protected`` (app public, code hidden) has no integer
                # equivalent, so it is preserved verbatim rather than forced
                # into a value that would misrepresent it.
                normalised["visibility"] = studio_visibility.value
        elif raw_visibility is None:
            private_flag = normalised.get("private")
            if normalised.get("gated"):
                # Checked before ``private``: the server reports ``private:
                # false`` for a gated repo, so trusting that flag first would
                # report an application-gated repo as public.
                normalised["visibility"] = Visibility.PRIVATE
            elif isinstance(private_flag, bool):
                normalised["visibility"] = Visibility.PRIVATE if private_flag else Visibility.PUBLIC

        # The OpenAPI list endpoints return ``id`` as "owner/name".
        # Split it so the computed ``repo_id`` property works.
        id_val = normalised.get("id")
        if isinstance(id_val, str) and "/" in id_val:
            parts = id_val.split("/", 1)
            if not normalised.get("owner"):
                normalised["owner"] = parts[0]
            if not normalised.get("name"):
                normalised["name"] = parts[1]

        if not normalised.get("owner"):
            normalised["owner"] = owner_hint
        if not normalised.get("name"):
            normalised["name"] = name_hint
        normalised["repo_type"] = repo_type
        return RepoInfo.from_dict(normalised)

    # ==================================================================
    # Authentication
    # ==================================================================
    def get_cookies(
        self,
        access_token: str | None = None,
        *,
        cookies_required: bool = False,
    ) -> RequestsCookieJar | None:
        """Get cookies for authentication from token or local cache.

        Resolution order:
        1. Explicit ``access_token`` argument
        2. Token from config (explicit arg > env var > persisted cookie)
        3. Saved cookies from ``~/.modelscope/credentials/cookies``

        When a token is available (steps 1-2), a fresh
        :class:`~requests.cookies.RequestsCookieJar` with ``m_session_id``
        is built. Otherwise the locally cached cookies from a prior
        ``login()`` call are loaded.

        Parameters
        ----------
        access_token : str, optional
            Explicit token override.
        cookies_required : bool, optional
            When ``True``, raise :class:`AuthenticationError` if no
            credentials are available. Default is ``False``.

        Returns
        -------
        RequestsCookieJar or None
            Cookie jar for authentication, or ``None`` when no
            credentials are available and ``cookies_required`` is ``False``.

        Raises
        ------
        AuthenticationError
            When ``cookies_required`` is ``True`` and no credentials found.

        Examples
        --------
        >>> cookies = api.get_cookies()
        >>> cookies['m_session_id']
        'ms-xxxxxxxx'
        """
        token = access_token or self._config.token
        if token:
            domain = urlparse(self._config.endpoint).hostname or ""
            jar = RequestsCookieJar()
            jar.set("m_session_id", token, domain=domain, path="/")
            return jar

        # An explicitly overridden (empty) token means "run without local
        # credentials" -- never silently fall back to the persisted cookies.
        if not getattr(self._config, "_token_overridden", False):
            cookies = self._config.load_cookies()
            if cookies is not None:
                return cookies

        if cookies_required:
            raise AuthenticationError(
                "No credentials found. "
                "Pass --token, call HubApi.login(), or set MODELSCOPE_API_TOKEN. "
                "Your token is available at https://modelscope.cn/my/myaccesstoken"
            )
        return None

    def login(self, token: str) -> UserInfo:
        """Authenticate and persist credentials locally.

        Calls ``POST /api/v1/login`` to obtain server-issued session cookies
        and a git access token, then saves them to
        ``~/.modelscope/credentials/`` (compatible with the old modelscope SDK).

        Parameters
        ----------
        token : str
            ModelScope API token. Must be non-empty after stripping.

        Returns
        -------
        UserInfo
            Profile of the authenticated user.

        Raises
        ------
        InvalidParameter
            When ``token`` is empty or whitespace-only.
        AuthenticationError
            When the server rejects the token. The server's own explanation is
            preserved, and an endpoint hint is appended when the token turns
            out to be valid on the peer ModelScope site.
        HubError
            Transport, timeout and server-side failures propagate unchanged --
            they are never reported as a rejected token.

        Notes
        -----
        A failed attempt leaves persisted credentials untouched. Until the
        server has accepted the new token, the stored credential is still the
        caller's only working one, so revoking it on failure would turn a
        mistyped token into an unintended logout.

        Tokens are issued with a permission tier (read / write / admin). The
        legacy login endpoint exists to mint git credentials, which a read-only
        token is not entitled to -- yet such a token authenticates fine and is
        all a caller needs in order to browse and download. So when that
        endpoint rejects the credential, the token is re-checked against
        ``GET /users/me`` before concluding it is bad: if that succeeds the
        login completes without cookies or a git token, and warns that write
        operations will need a higher tier.

        Examples
        --------
        >>> api = HubApi()
        >>> user = api.login("ms-xxxxxxxx")
        >>> user.username
        'alice'
        """
        if not token or not token.strip():
            raise InvalidParameter("token must be a non-empty string")

        token = token.strip()
        previous_token = self._config.token
        previous_logged_out = self._config._logged_out
        self._config.token = token
        self._config._logged_out = False
        self._openapi = None
        if self._legacy is not None:
            self._legacy.token = token

        try:
            data, cookies = self.legacy.login(token)
        except (AuthenticationError, PermissionDeniedError) as exc:
            scoped = self._login_with_scoped_token(token)
            if scoped is not None:
                return scoped
            self._restore_credential_state(previous_token, previous_logged_out)
            explained = self._explain_login_failure(token, exc)
            if explained is exc:
                raise
            raise explained from exc
        except HubError as exc:
            self._restore_credential_state(previous_token, previous_logged_out)
            explained = self._explain_login_failure(token, exc)
            if explained is exc:
                raise
            raise explained from exc

        git_token = data.get("AccessToken", "")
        username = data.get("Username", "")
        email = data.get("Email", "")

        self._config.save_cookies(cookies)
        if git_token:
            self._config.save_git_token(git_token)
        else:
            logger.debug("Login returned no git access token; git-based operations will be unavailable.")
        if username:
            self._config.save_user_info(username, email or "")

        return self.whoami()

    def _login_with_scoped_token(self, token: str) -> UserInfo | None:
        """Complete a reduced-capability login, or return ``None`` if impossible.

        Called only when the legacy login endpoint refused the credential, at
        which point *token* is already installed on the config -- so a successful
        ``GET /users/me`` proves the token itself is valid, and the refusal was
        about the permission tier rather than the token. Reporting that as
        "invalid token" would send the caller after the wrong remedy.

        The token has to be persisted explicitly here. On the normal path it is
        stored as a side effect of saving the server-issued session cookies,
        which this tier does not receive -- without this the login would appear
        to succeed yet leave nothing on disk for the next process to find.

        Like :meth:`_token_valid_on`, the probe is advisory: retries are disabled
        so a dead network cannot stall the error report, and any exception simply
        means "cannot confirm", which hands the original rejection back untouched.
        """
        from .constants import API_CONNECT_TIMEOUT

        probe = OpenAPIClient(
            self._config, timeout=API_CONNECT_TIMEOUT, max_retries=0, user_agent=self._user_agent_extra
        )
        try:
            payload = probe.get_current_user()
        except Exception:  # advisory only -- never mask the original failure
            return None
        finally:
            probe.close()

        profile = UserInfo.from_dict(payload if isinstance(payload, dict) else {})
        if not profile.username:
            return None
        logger.warning(
            "Token accepted with reduced permissions: signed in as %s, but git and session "
            "credentials were not issued. Uploads, pushes and other write operations need a "
            "token with 'write' permission or higher.",
            profile.username,
        )
        self._config.save_token(token)
        self._config.save_user_info(profile.username, profile.email or "")
        return profile

    def _restore_credential_state(self, token: str | None, logged_out: bool) -> None:
        """Roll the in-memory credential back to its pre-login value.

        Persisted credentials are deliberately left alone; only this instance's
        transient state is rewound, so a failed attempt leaves the object
        exactly as it was found instead of poisoning it with a rejected token.
        """
        self._config.token = token
        self._config._logged_out = logged_out
        self._openapi = None
        if self._legacy is not None:
            self._legacy.token = token

    def _explain_login_failure(self, token: str, exc: HubError) -> HubError:
        """Return the exception to surface for a failed login attempt.

        Only authentication failures are re-worded. Network, timeout and
        server-side errors are handed back untouched, because presenting them
        as a rejected token would send the caller after the wrong remedy.

        The two ModelScope sites keep separate account systems and answer an
        unknown token with the same business code, so the server cannot tell
        "invalid token" apart from "token issued by the other site". Only the
        client knows which site it addressed, which is why that disambiguation
        has to happen here.
        """
        if not isinstance(exc, AuthenticationError):
            return exc
        peer = self._peer_site_endpoint()
        if peer is None or not self._token_valid_on(
            token, peer, user_agent=build_user_agent(config=self._config, extra=self._user_agent_extra)
        ):
            return exc
        return AuthenticationError(
            f"{exc.message} This token is valid on {peer} instead; retry with "
            f"--endpoint {peer} (or set MODELSCOPE_ENDPOINT={peer}).",
            status_code=exc.status_code,
            request_id=exc.request_id,
            response_body=exc.response_body,
            url=exc.url,
            method=exc.method,
        )

    def _peer_site_endpoint(self) -> str | None:
        """Return the sibling ModelScope site, or ``None`` when not applicable.

        An explicitly configured endpoint is always respected, mirroring
        :meth:`resolve_endpoint_for_read`: when the caller has pinned a site we
        do not second-guess it.
        """
        if self._config._endpoint_overridden:
            return None
        from .constants import DEFAULT_INTL_ENDPOINT

        def site_key(url: str) -> str:
            host = (urlparse(url).hostname or "").lower()
            return host[4:] if host.startswith("www.") else host

        current = site_key(self._config.endpoint or DEFAULT_ENDPOINT)
        for candidate in (DEFAULT_ENDPOINT, DEFAULT_INTL_ENDPOINT):
            if site_key(candidate) != current:
                return candidate
        return None

    @staticmethod
    def _token_valid_on(token: str, endpoint: str, *, user_agent: str | None = None) -> bool:
        """Best-effort check of whether *token* authenticates against *endpoint*.

        Runs on the failure path only and is strictly advisory: any error means
        "cannot confirm", so a probe outage degrades to the plain server message
        rather than producing a misleading hint. Retries are disabled to keep
        the failure path responsive.
        """
        from .constants import API_CONNECT_TIMEOUT

        probe = LegacyClient(
            token=None,
            endpoint=endpoint,
            timeout=API_CONNECT_TIMEOUT,
            max_retries=0,
            user_agent=user_agent or build_user_agent(config=get_default_config()),
        )
        try:
            probe.login(token)
        except Exception:  # advisory only -- never mask the original failure
            return False
        return True

    def logout(self) -> None:
        """Clear the locally persisted token.

        Cached HTTP clients are reset so subsequent calls behave as if
        no credential was ever provided.

        Examples
        --------
        >>> api.logout()
        """
        self._config.clear_token()
        self._openapi = None
        if self._legacy is not None:
            self._legacy.token = None

    def whoami(self) -> UserInfo:
        """Return the profile for the currently authenticated user.

        Returns
        -------
        UserInfo
            Authenticated user profile (username, email, avatar, ...).

        Raises
        ------
        AuthenticationError
            When no token is configured or the token is invalid.

        Examples
        --------
        >>> from modelscope_hub import HubApi
        >>> api = HubApi(token="ms-xxxxxxxx")
        >>> user = api.whoami()
        >>> print(user.username, user.email)
        alice alice@example.com
        """
        payload = self.openapi.get_current_user()
        return UserInfo.from_dict(payload if isinstance(payload, dict) else {})

    # ==================================================================
    # Unified repo CRUD
    # ==================================================================
    def create_repo(
        self,
        repo_id: str,
        repo_type: RepoTypeLike,
        *,
        visibility: int | str | Visibility | None = None,
        license: str | None = None,
        chinese_name: str | None = None,
        description: str | None = None,
        gated_mode: bool | None = None,
        license_name: str | None = None,
        license_link: str | None = None,
        task: str | None = None,
        **extra: Any,
    ) -> RepoInfo:
        """Create a new repository.

        Routing is decided by ``repo_type``:

        * ``studio`` / ``skill`` → OpenAPI ``POST /studios`` / ``POST /skills``
        * ``model`` / ``dataset`` → OpenAPI ``POST /models`` / ``POST /datasets``,
          falling back to the legacy endpoint for inputs the OpenAPI schema
          cannot express (see :meth:`_legacy_create_reason`)

        Parameters
        ----------
        repo_id : str
            Canonical ``owner/name`` identifier.
        repo_type : str or RepoType
            One of ``"model"``, ``"dataset"``, ``"studio"``, ``"skill"``.
        visibility : int, str or Visibility, optional
            Visibility level. Accepts the integer wire encoding, a label
            (``"public"`` / ``"private"`` / ``"internal"``) or a
            :class:`Visibility` value. Defaults to public.
        license : str, optional
            SPDX-style license identifier (e.g. ``"apache-2.0"``). Values the
            OpenAPI model schema does not list are still accepted, via the
            legacy endpoint.
        chinese_name : str, optional
            Display name shown on the Hub UI.
        description : str, optional
            Short description of the repository.
        gated_mode : bool, optional
            Historical application-access switch, not deprecated. Effective
            only for private repositories; explicit public/internal visibility
            takes precedence and the switch is warned about and ignored.
            Either explicit boolean with omitted visibility implies private.
            These calls retain the legacy ProtectedMode=1/2 request format.
            This boolean does not select an approval policy.
        license_name : str, optional
            Custom license name. Required when ``license="other"``.
        license_link : str, optional
            Custom license URL, honoured when ``license="other"``. When omitted
            the Hub creates a blank ``LICENSE.md``.
        task : str, optional
            Model task identifier, as published by
            :meth:`list_model_options`. Models only.
        **extra : Any
            Additional fields forwarded verbatim to the underlying client.

        Returns
        -------
        RepoInfo
            Metadata of the newly created repository.

        Raises
        ------
        InvalidParameter
            When ``repo_id`` does not have the ``owner/name`` shape, or when
            ``visibility`` is a value the repo type does not support.
        AuthenticationError
            When the token is missing or invalid.

        Examples
        --------
        Create a private model repository:

        >>> info = api.create_repo(
        ...     "alice/llama-7b-finetuned",
        ...     repo_type="model",
        ...     visibility="private",
        ...     license="apache-2.0",
        ...     description="A LoRA fine-tune of LLaMA-7B",
        ... )
        >>> info.repo_id
        'alice/llama-7b-finetuned'

        Create a private dataset with application-gated access:

        >>> api.create_repo("alice/my-data", "dataset", visibility="private", gated_mode=True)

        Create a public Studio space:

        >>> api.create_repo("alice/chat-demo", repo_type="studio", visibility="public")
        """
        self._reject_removed_gating_parameters(extra)
        rt = self._normalize_repo_type(repo_type)
        if rt not in _CREATABLE_TYPES:
            supported = ", ".join(sorted(t.value for t in _CREATABLE_TYPES))
            raise NotSupportedError(
                f"create_repo does not support repo_type={rt.value!r}. Supported types: {supported}."
            )
        owner, name = self._parse_repo_id(repo_id)
        studio_visibility = StudioVisibility.parse(visibility) if rt is RepoType.STUDIO else None
        vis = None if studio_visibility is not None else self._normalize_visibility(visibility)
        if license is not None:
            license = _LICENSE_DISPLAY_TO_SPDX.get(license, license)

        if rt in _LEGACY_CREATE_FALLBACK_TYPES:
            return self._create_model_or_dataset(
                rt,
                owner,
                name,
                visibility=vis,
                license=license,
                chinese_name=chinese_name,
                description=description,
                gated_mode=gated_mode,
                license_name=license_name,
                license_link=license_link,
                task=task,
                extra=extra,
            )

        is_private = vis is not None and vis == int(Visibility.PRIVATE)
        if rt is RepoType.STUDIO:
            payload: dict[str, Any] = {
                "owner": owner,
                "repo_name": name,
            }
            if studio_visibility is not None:
                # ``visibility`` is the expressive form (it is the only way to
                # ask for ``protected``); ``private`` is sent alongside it for
                # servers that predate the tri-state field. The two are
                # consistent by construction, so they cannot disagree.
                payload["visibility"] = studio_visibility.value
                payload["private"] = studio_visibility is StudioVisibility.PRIVATE
            elif vis is not None:
                payload["private"] = is_private
            if chinese_name is not None:
                payload["display_name"] = chinese_name
        else:
            payload = {
                "owner": owner,
                "skill_name": name,
            }
            if vis is not None:
                payload["private"] = is_private
            if chinese_name is not None:
                payload["display_name"] = chinese_name
        if license is not None:
            payload["license"] = license
        if description is not None:
            payload["description"] = description
        # Only Studios get the Studio field normalisation: a Skill has no
        # cover image and no visibility field, so rewriting those keys on a
        # Skill payload would invent fields its endpoint does not accept.
        payload.update(_normalise_studio_fields(extra) if rt is RepoType.STUDIO else extra)
        data = self.openapi.create_studio(payload) if rt is RepoType.STUDIO else self.openapi.create_skill(payload)
        return self._repo_info_from_payload(data, rt, owner_hint=owner, name_hint=name)

    @staticmethod
    def _reject_removed_gating_parameters(parameters: Mapping[str, Any]) -> None:
        """Reject removed request parameters before kwargs can reach a backend."""
        removed = sorted({"approval_mode", "gated"} & set(parameters))
        if removed:
            raise TypeError(f"Unexpected keyword argument(s): {', '.join(removed)}; use gated_mode=True/False.")

    @staticmethod
    def _legacy_create_reason(
        rt: RepoType,
        *,
        visibility: int | None,
        license: str | None,
        extra: Mapping[str, Any],
        gated_mode: bool | None = None,
        task: str | None = None,
    ) -> str | None:
        """Explain why these inputs cannot go through the OpenAPI create endpoint.

        The OpenAPI schemas are closed: ``visibility`` has no ``internal``,
        ``POST /models`` restricts ``license`` to a published set, and both
        endpoints answer 400 for any field they do not declare. The legacy
        endpoint accepts all three, so rather than failing a call that works
        today, these inputs keep using it. Returns ``None`` when the OpenAPI
        endpoint can serve the request.
        """
        if gated_mode is not None:
            # Retain the historical boolean wire contract, not a new policy selector.
            return "historical gated_mode boolean keeps the legacy ProtectedMode wire"
        if visibility is not None and visibility == int(Visibility.INTERNAL):
            return "visibility=internal is not part of the OpenAPI visibility enum"
        if rt is RepoType.MODEL and license is not None and license not in OPENAPI_MODEL_LICENSES:
            return f"license={license!r} is not in the OpenAPI model license enum"
        if rt is not RepoType.MODEL and task is not None:
            # Only the model schema declares ``task``. The legacy endpoint used
            # to receive it verbatim through ``**extra``, so route there rather
            # than reject a call that used to work.
            return f"task is not declared by the OpenAPI {rt.value} create schema"
        allowed = OPENAPI_CREATE_MODEL_FIELDS if rt is RepoType.MODEL else OPENAPI_CREATE_DATASET_FIELDS
        unknown = sorted(set(extra) - allowed)
        if unknown:
            return f"field(s) {unknown} are not declared by the OpenAPI create schema"
        return None

    def _create_model_or_dataset(
        self,
        rt: RepoType,
        owner: str,
        name: str,
        *,
        visibility: int | None,
        license: str | None,
        chinese_name: str | None,
        description: str | None,
        gated_mode: bool | None,
        license_name: str | None,
        license_link: str | None,
        task: str | None,
        extra: Mapping[str, Any],
    ) -> RepoInfo:
        """Create a model or dataset, preferring OpenAPI over the legacy endpoint."""
        if gated_mode is not None and not isinstance(gated_mode, bool):
            raise InvalidParameter("gated_mode must be True, False or None, not an approval-policy string.")
        reason = self._legacy_create_reason(
            rt,
            visibility=visibility,
            license=license,
            extra=extra,
            gated_mode=gated_mode,
            task=task,
        )
        if reason is None:
            try:
                return self._create_via_openapi(
                    rt,
                    owner,
                    name,
                    visibility=visibility,
                    license=license,
                    chinese_name=chinese_name,
                    description=description,
                    license_name=license_name,
                    license_link=license_link,
                    task=task,
                    extra=extra,
                )
            except (NotExistError, ServerError) as exc:
                # 404 means this deployment has not published the endpoint yet;
                # 501 means it knows the route but will not serve it. Both are
                # "not available here", so fall through rather than fail.
                if exc.status_code not in (404, 501):
                    raise
                reason = f"the OpenAPI create endpoint answered {exc.status_code}"
        logger.debug("Creating %s %s/%s through the legacy endpoint: %s", rt.value, owner, name, reason)
        return self._create_via_legacy(
            rt,
            owner,
            name,
            visibility=visibility,
            license=license,
            chinese_name=chinese_name,
            description=description,
            gated_mode=gated_mode,
            # ``task`` / ``license_name`` / ``license_link`` are named parameters
            # only because the OpenAPI schema declares them. The legacy endpoint
            # has always received them through ``**extra`` under exactly these
            # keys, so they are restored rather than renamed -- a legacy request
            # must not change shape just because the signature grew.
            extra={
                **extra,
                **({"task": task} if task is not None else {}),
                **({"license_name": license_name} if license_name is not None else {}),
                **({"license_link": license_link} if license_link is not None else {}),
            },
        )

    def _create_via_openapi(
        self,
        rt: RepoType,
        owner: str,
        name: str,
        *,
        visibility: int | None,
        license: str | None,
        chinese_name: str | None,
        description: str | None,
        license_name: str | None,
        license_link: str | None,
        task: str | None,
        extra: Mapping[str, Any],
    ) -> RepoInfo:
        """Create a model or dataset via ``POST /models`` / ``POST /datasets``."""
        payload: dict[str, Any] = {"owner": owner, "repo_name": name}
        wire_visibility = self._openapi_visibility(rt, visibility)
        if wire_visibility is not None:
            payload["visibility"] = wire_visibility.value
        if chinese_name is not None:
            payload["display_name"] = chinese_name
        # ``license`` is omitted rather than defaulted: the server's own default
        # (``apache-2.0``) is inside the enum, whereas the legacy fallback value
        # (``"Apache-2.0"``) is not and would be rejected.
        if license is not None:
            payload["license"] = license
        if license_name is not None:
            payload["license_name"] = license_name
        if license_link is not None:
            payload["license_link"] = license_link
        if description is not None:
            payload["description"] = description
        if task is not None:
            if rt is not RepoType.MODEL:
                raise InvalidParameter("task is only supported for repo_type='model'.")
            payload["task"] = task
        payload.update(extra)

        try:
            data = self.openapi.create_model(payload) if rt is RepoType.MODEL else self.openapi.create_dataset(payload)
        except InvalidParameter as exc:
            # ``POST /datasets`` declares no 409, so a duplicate may arrive as a
            # 400. Callers catch AlreadyExistsError, so reclassify rather than
            # let a rename of an existing repo look like bad input.
            if not isinstance(exc, AlreadyExistsError) and is_repo_exists_error(exc):
                raise AlreadyExistsError(
                    str(exc.message or exc),
                    status_code=exc.status_code,
                    request_id=exc.request_id,
                    response_body=exc.response_body,
                ) from exc
            raise
        info = self._repo_info_from_payload(data, rt, owner_hint=owner, name_hint=name)
        # The create response carries only identity fields, while the legacy one
        # echoed the settings back. Backfill from the request so a caller reading
        # ``info.visibility`` after create does not see None where it saw a value.
        # Backfill enum instances, not bare ints, after dataclass construction.
        if info.visibility is None and wire_visibility is not None:
            info.visibility = Visibility.PUBLIC if wire_visibility is RepoVisibility.PUBLIC else Visibility.PRIVATE
        if info.license is None:
            info.license = license
        if info.description is None:
            info.description = description
        if info.gated is None:
            info.gated = False
        return info

    @staticmethod
    def _openapi_visibility(rt: RepoType, visibility: int | None) -> RepoVisibility | None:
        """Map historical ordinary visibility values to OpenAPI strings.

        None omits the field, retaining the public server default. Internal
        visibility and explicit application switches are routed to legacy
        before this helper is called.
        """
        if visibility is None:
            return None
        if visibility == int(Visibility.PRIVATE):
            return RepoVisibility.PRIVATE
        if visibility == int(Visibility.PUBLIC):
            return RepoVisibility.PUBLIC
        raise InvalidParameter(f"visibility={visibility!r} is not supported by the OpenAPI {rt.value} create endpoint.")

    def _create_via_legacy(
        self,
        rt: RepoType,
        owner: str,
        name: str,
        *,
        visibility: int | None,
        license: str | None,
        chinese_name: str | None,
        description: str | None,
        gated_mode: bool | None,
        extra: Mapping[str, Any],
    ) -> RepoInfo:
        """Create a model or dataset via the legacy ``POST /api/v1/{type}s``.

        The body is built in the order this endpoint has always received it, and
        ``extra`` is appended last and verbatim. Callers reach this path because
        the OpenAPI schema could not express their input, so the request they
        get must be the one they got before the OpenAPI route existed.
        """
        vis = visibility
        if rt is RepoType.DATASET:
            body: dict[str, Any] = {
                "Owner": owner,
                "Name": name,
                "Visibility": vis if vis is not None else int(Visibility.PUBLIC),
                "License": license or "Apache-2.0",
            }
        else:
            body = {
                "Path": owner,
                "Name": name,
                "Visibility": vis if vis is not None else int(Visibility.PUBLIC),
                "License": license or "Apache-2.0",
            }
        if chinese_name is not None:
            body["ChineseName"] = chinese_name
        if description is not None:
            body["Description"] = description

        # Preserve v0.5.1: either explicit boolean with no visibility implies
        # PRIVATE; public/internal visibility wins and ignores the switch.
        if gated_mode is not None:
            if vis is None:
                vis = int(Visibility.PRIVATE)
                body["Visibility"] = vis
                body["ProtectedMode"] = 1 if gated_mode else 2
            elif vis == int(Visibility.PRIVATE):
                body["ProtectedMode"] = 1 if gated_mode else 2
            else:
                logger.warning("gated_mode is only effective when visibility is PRIVATE, ignored.")

        # Blocklist filtering: only reject fields controlled by method params.
        filtered: dict[str, Any] = {}
        for k, v in extra.items():
            if k in _RESERVED_EXTRA_FIELDS:
                logger.warning("Reserved field %r in extra ignored (controlled by method params)", k)
                continue
            filtered[k] = v
        if "ProtectedMode" in filtered:
            pm = filtered["ProtectedMode"]
            if not isinstance(pm, int) or isinstance(pm, bool) or pm not in (1, 2):
                raise ValueError("ProtectedMode must be int 1 (gated) or 2 (off); use gated_mode=True/False instead")
        body.update(filtered)

        data = self.legacy.create_repo(repo_type=str(rt), body=body)
        return self._repo_info_from_payload(data, rt, owner_hint=owner, name_hint=name)

    def get_repo(
        self,
        repo_id: str,
        repo_type: RepoTypeLike,
        *,
        revision: str | None = None,  # noqa: ARG002 - reserved for future use
    ) -> RepoInfo:
        """Fetch a repository's metadata via the OpenAPI surface.

        Parameters
        ----------
        repo_id : str
            Canonical ``owner/name`` identifier.
        repo_type : str or RepoType
            One of ``"model"``, ``"dataset"``, ``"studio"``, ``"skill"``, ``"mcp"``.
        revision : str, optional
            Reserved for future use; currently ignored.

        Returns
        -------
        RepoInfo
            Repository metadata (id, owner, name, visibility, stats, ...).

        Raises
        ------
        NotExistError
            When the repository does not exist or is not visible to the caller.
        AuthenticationError
            When the request requires auth and the token is missing or invalid.

        Examples
        --------
        >>> info = api.get_repo("alice/llama-7b", repo_type="model")
        >>> info.visibility
        'public'
        >>> info.downloads
        1234
        """
        rt = self._normalize_repo_type(repo_type)
        owner, name = self._parse_repo_id(repo_id)

        if rt is RepoType.MODEL:
            try:
                data = self.openapi.get_model(owner, name)
            except NotExistError:
                data = self.legacy.get_repo_info(repo_id, str(rt))
        elif rt is RepoType.DATASET:
            try:
                data = self.openapi.get_dataset(owner, name)
            except NotExistError:
                logger.debug(
                    "Dataset %s/%s not found in OpenAPI, falling back to legacy API",
                    owner,
                    name,
                )
                data = self.legacy.get_repo_info(repo_id, str(rt))
        elif rt is RepoType.STUDIO:
            data = self.openapi.get_studio(owner, name)
        elif rt is RepoType.SKILL:
            data = self.openapi.get_skill(f"{owner}/{name}")
        elif rt is RepoType.MCP:
            data = self.openapi.get_mcp_server(f"{owner}/{name}")
        else:  # pragma: no cover - defensive
            raise NotSupportedError(f"get_repo not supported for {rt}")

        return self._repo_info_from_payload(data, rt, owner_hint=owner, name_hint=name)

    def get_model(self, repo_id: str) -> dict:
        """Fetch a model's full detail payload, zone fields included.

        Returns the server's ``ModelDetail`` verbatim (snake_case keys) rather
        than a :class:`RepoInfo`. The zone-specific fields -- AIGC architecture
        and ``versions``, or the science subject areas -- have no place on the
        dataclass, and :meth:`get_repo` would silently drop them.

        Which keys are present depends on ``model_category``: ``base`` carries
        no zone fields, and the fields of the zones a model is *not* in are
        absent rather than null. Read them with ``.get()``.

        Parameters
        ----------
        repo_id : str
            Canonical ``owner/name`` identifier.

        Returns
        -------
        dict
            The ``ModelDetail`` payload.

        Examples
        --------
        >>> detail = api.get_model("alice/my-anime-lora")
        >>> detail["model_category"]
        'aigc'
        >>> [v["version_id"] for v in detail.get("versions", [])]
        [1070760]
        """
        owner, name = self._parse_repo_id(repo_id)
        data = self.openapi.get_model(owner, name)
        return dict(data) if isinstance(data, Mapping) else {}

    def model_info(self, repo_id: str) -> dict:
        """Alias of :meth:`get_model`."""
        return self.get_model(repo_id)

    def get_dataset(self, repo_id: str) -> dict:
        """Fetch a dataset's full detail payload, zone fields included.

        The dataset counterpart of :meth:`get_model`; see there for why the raw
        payload is returned instead of a :class:`RepoInfo`. Science datasets
        additionally carry the subject areas and cover image.

        Examples
        --------
        >>> detail = api.get_dataset("alice/rna-seq")
        >>> detail["dataset_category"], detail.get("primary_subject_area")
        ('science', 'life-sciences')
        """
        owner, name = self._parse_repo_id(repo_id)
        data = self.openapi.get_dataset(owner, name)
        return dict(data) if isinstance(data, Mapping) else {}

    def dataset_info(self, repo_id: str) -> dict:
        """Alias of :meth:`get_dataset`."""
        return self.get_dataset(repo_id)

    # ==================================================================
    # Zone configuration enums
    # ==================================================================
    def list_aigc_model_options(self) -> dict:
        """Return the enum values accepted when setting the AIGC category.

        Needs no credentials. Every option is a ``{type, id, label}`` triple:
        pass ``id`` to :meth:`set_model_category`, show ``label`` to users.

        Returns
        -------
        dict
            ``aigc_types``, ``base_architectures`` (each with ``subtypes``),
            ``content_styles``, ``content_functions``, ``content_elements``.

        Examples
        --------
        >>> options = api.list_aigc_model_options()
        >>> for arch in options["base_architectures"]:
        ...     print(arch["id"], [s["id"] for s in arch["subtypes"]])
        """
        data = self.openapi.list_aigc_model_options()
        return dict(data) if isinstance(data, Mapping) else {}

    def list_science_model_options(self) -> dict:
        """Return the science-model subject-area tree. Needs no credentials.

        Examples
        --------
        >>> tree = api.list_science_model_options()
        >>> tree["subject_areas"][0]["id"]
        'life-sciences'
        """
        data = self.openapi.list_science_model_options()
        return dict(data) if isinstance(data, Mapping) else {}

    def list_science_dataset_options(self) -> dict:
        """Return the science-dataset subject-area tree. Needs no credentials."""
        data = self.openapi.list_science_dataset_options()
        return dict(data) if isinstance(data, Mapping) else {}

    def list_model_options(self) -> dict:
        """Return the valid model ``task`` and ``license`` values.

        Needs no credentials. Each entry is a ``{type, id, label}`` triple; pass
        ``id`` to :meth:`create_repo` or :meth:`update_repo_settings`.

        Returns
        -------
        dict
            ``tasks`` and ``license`` lists.

        Examples
        --------
        >>> options = api.list_model_options()
        >>> [t["id"] for t in options["tasks"]][:2]
        ['text-generation', 'image-captioning']
        """
        data = self.openapi.get_model_options()
        return dict(data) if isinstance(data, Mapping) else {}

    # ==================================================================
    # Zone membership (category)
    # ==================================================================
    def set_model_category(
        self,
        repo_id: str,
        repo_type: RepoTypeLike = RepoType.MODEL,
        *,
        model_category: str | ModelCategory,
        **fields: Any,
    ) -> dict:
        """Set or change which zone a model belongs to.

        Which fields are required follows from the *target* category, not from
        the model's current one. Upload the weight files first: the endpoint
        validates that each ``path_in_repo`` already exists.

        * ``base`` -- no other field; every zone field is cleared.
        * ``aigc`` -- ``aigc_type``, ``base_model_architecture_type``,
          ``base_model_architecture_subtype``, ``version_name``, and non-empty
          ``weight_files`` and ``sample_images``. Creates a new version.
        * ``science`` -- ``primary_subject_area`` and
          ``secondary_specialization``; ``cover_image`` optional.

        Enum values come from :meth:`list_aigc_model_options` /
        :meth:`list_science_model_options`; pass each option's ``id``.

        Parameters
        ----------
        repo_id : str
            Canonical ``owner/name`` identifier.
        repo_type : str or RepoType, optional
            Must be ``"model"``. Accepted for symmetry with the other methods.
        model_category : str or ModelCategory
            Target zone: ``"base"``, ``"aigc"`` or ``"science"``.
        **fields : Any
            Zone fields for the target category.

        Returns
        -------
        dict
            Repository identity (``id``, ``repo_name``, ``owner``, ``url``).

        Raises
        ------
        NotSupportedError
            When ``repo_type`` is not ``"model"``.
        InvalidParameter
            When ``model_category`` is unknown, or when a required AIGC field is
            missing or malformed.

        Examples
        --------
        >>> api.set_model_category(
        ...     "alice/my-anime-lora",
        ...     model_category="aigc",
        ...     aigc_type="LoRA",
        ...     base_model_architecture_type="Z_IMAGE_TURBO",
        ...     base_model_architecture_subtype="Z_IMAGE_TURBO",
        ...     version_name="v1.0",
        ...     weight_files=[{"path_in_repo": "model.safetensors"}],
        ...     sample_images=[{"url": "https://example.com/a.png", "prompt": "anime girl"}],
        ... )

        Move it back out of the zone:

        >>> api.set_model_category("alice/my-anime-lora", model_category="base")
        """
        rt = self._normalize_repo_type(repo_type)
        if rt is not RepoType.MODEL:
            raise NotSupportedError(f"set_model_category only supports repo_type='model' (got {rt.value!r}).")
        owner, name = self._parse_repo_id(repo_id)
        category = self._coerce_enum(model_category, ModelCategory, "model_category")
        payload: dict[str, Any] = {"model_category": category.value}
        payload.update(fields)
        self._validate_set_model_category(category, payload)
        data = self.openapi.set_model_category(owner, name, payload)
        return dict(data) if isinstance(data, Mapping) else {}

    def update_model_category(
        self,
        repo_id: str,
        repo_type: RepoTypeLike = RepoType.MODEL,
        *,
        version_id: int | None = None,
        version_name: str | None = None,
        **fields: Any,
    ) -> dict:
        """Update a model's zone metadata in place, without changing the zone.

        The server reads the current zone from its own records, so the category
        is neither needed nor accepted. Use :meth:`set_model_category` to move
        between zones or to replace an existing version's weights.

        AIGC version fields (``trigger_words``, ``version_description``,
        ``sample_images``) address a specific version. Give either its numeric
        ``version_id`` or its ``version_name``, which is resolved to the id with
        one extra detail read. Science updates need neither.

        Omitted fields are left unchanged; passing ``None`` clears a field.

        Parameters
        ----------
        repo_id : str
            Canonical ``owner/name`` identifier.
        repo_type : str or RepoType, optional
            Must be ``"model"``.
        version_id : int, optional
            Numeric version id, as reported by :meth:`get_model`.
        version_name : str, optional
            Version name to resolve into ``version_id``. Ignored when
            ``version_id`` is given.
        **fields : Any
            Zone fields to update.

        Returns
        -------
        dict
            Repository identity.

        Raises
        ------
        NotSupportedError
            When ``repo_type`` is not ``"model"``.
        InvalidParameter
            When a field belongs to :meth:`set_model_category` instead, or when
            ``version_name`` matches no version.

        Examples
        --------
        >>> api.update_model_category(
        ...     "alice/my-anime-lora",
        ...     version_name="v1.0",
        ...     trigger_words=["anime style"],
        ... )
        >>> api.update_model_category("alice/rna-predictor", secondary_specialization="dna")
        """
        rt = self._normalize_repo_type(repo_type)
        if rt is not RepoType.MODEL:
            raise NotSupportedError(f"update_model_category only supports repo_type='model' (got {rt.value!r}).")
        owner, name = self._parse_repo_id(repo_id)
        payload = self._strip_category_discriminator(dict(fields), "model_category", "set_model_category")
        self._reject_set_only_fields(payload)
        if version_id is None and version_name is not None:
            version_id = self._resolve_version_id(repo_id, version_name)
        if version_id is not None:
            payload["version_id"] = version_id
        data = self.openapi.update_model_category(owner, name, payload)
        return dict(data) if isinstance(data, Mapping) else {}

    def set_dataset_category(
        self,
        repo_id: str,
        repo_type: RepoTypeLike = RepoType.DATASET,
        *,
        dataset_category: str | DatasetCategory,
        **fields: Any,
    ) -> dict:
        """Set or change which zone a dataset belongs to.

        ``science`` requires a matching ``primary_subject_area`` and
        ``secondary_specialization`` (ids from
        :meth:`list_science_dataset_options`); ``base`` clears them. Note the
        general value is ``base``, not ``basic``.

        Examples
        --------
        >>> api.set_dataset_category(
        ...     "alice/rna-seq",
        ...     dataset_category="science",
        ...     primary_subject_area="life-sciences",
        ...     secondary_specialization="dna",
        ... )
        """
        rt = self._normalize_repo_type(repo_type)
        if rt is not RepoType.DATASET:
            raise NotSupportedError(f"set_dataset_category only supports repo_type='dataset' (got {rt.value!r}).")
        owner, name = self._parse_repo_id(repo_id)
        category = self._coerce_enum(dataset_category, DatasetCategory, "dataset_category")
        payload: dict[str, Any] = {"dataset_category": category.value}
        payload.update(fields)
        data = self.openapi.set_dataset_category(owner, name, payload)
        return dict(data) if isinstance(data, Mapping) else {}

    def update_dataset_category(
        self,
        repo_id: str,
        repo_type: RepoTypeLike = RepoType.DATASET,
        **fields: Any,
    ) -> dict:
        """Update a dataset's science fields in place, without changing the zone.

        As with :meth:`update_model_category`, the category is read by the
        server and is not accepted in the payload. Omitted fields are left
        unchanged; ``None`` clears a field.

        Examples
        --------
        >>> api.update_dataset_category("alice/rna-seq", secondary_specialization="medicine")
        >>> api.update_dataset_category("alice/rna-seq", cover_image=None)
        """
        rt = self._normalize_repo_type(repo_type)
        if rt is not RepoType.DATASET:
            raise NotSupportedError(f"update_dataset_category only supports repo_type='dataset' (got {rt.value!r}).")
        owner, name = self._parse_repo_id(repo_id)
        payload = self._strip_category_discriminator(dict(fields), "dataset_category", "set_dataset_category")
        data = self.openapi.update_dataset_category(owner, name, payload)
        return dict(data) if isinstance(data, Mapping) else {}

    # ------------------------------------------------------------------
    # Category payload checks
    #
    # Each rule below mirrors one the server enforces. They run locally so a
    # request that is certain to fail reports the fix straight away instead of
    # costing a round trip for a generic 400. Anything whose valid values the
    # server owns (architectures, subject areas, tasks) is deliberately not
    # checked here -- those enums change without an SDK release, and its 400
    # message already names the offending field and the options endpoint.
    # ------------------------------------------------------------------
    @staticmethod
    def _coerce_enum(value: Any, enum_cls: type[_StrEnumT], field: str) -> _StrEnumT:
        """Coerce *value* into *enum_cls*, naming the valid values when it fails."""
        if isinstance(value, enum_cls):
            return value
        try:
            return enum_cls(str(value))
        except ValueError as exc:
            allowed = ", ".join(repr(member.value) for member in enum_cls)
            raise InvalidParameter(f"{field} must be one of {allowed} (got {value!r}).") from exc

    @staticmethod
    def _strip_category_discriminator(payload: dict[str, Any], field: str, setter: str) -> dict[str, Any]:
        """Drop the category discriminator from a PATCH payload.

        The endpoint answers 400 if the field is present at all -- it reads the
        current category itself. Earlier drafts of this API required the field,
        so it is removed with a warning rather than forwarded into a failure.
        """
        if field in payload:
            payload.pop(field)
            logger.warning(
                "%s is not accepted when updating zone fields and was dropped; use %s() to change the category.",
                field,
                setter,
            )
        return payload

    @staticmethod
    def _reject_set_only_fields(payload: Mapping[str, Any]) -> None:
        """Reject fields that only ``set_model_category`` can change.

        An existing version's weights are immutable; changing them means
        creating a new version. Saying so here is more useful than relaying the
        server's rejection.

        ``version_name`` is absent from this list on purpose: the method takes
        it as a named argument and resolves it to a ``version_id``, so it never
        reaches the payload.
        """
        offenders = sorted({"weight_files", "base_model_id"} & set(payload))
        if offenders:
            raise InvalidParameter(
                f"{', '.join(offenders)} cannot be changed on an existing version. "
                f"Use set_model_category(model_category='aigc', ...) to create a new version instead."
            )

    @classmethod
    def _validate_set_model_category(cls, category: ModelCategory, payload: Mapping[str, Any]) -> None:
        """Check the required-field rules for a zone transition."""
        if category is not ModelCategory.AIGC:
            return
        missing = sorted(
            field
            for field in (
                "aigc_type",
                "base_model_architecture_type",
                "base_model_architecture_subtype",
                "version_name",
                "weight_files",
                "sample_images",
            )
            if not payload.get(field)
        )
        if missing:
            raise InvalidParameter(
                f"model_category='aigc' requires non-empty {', '.join(missing)}. "
                f"Valid enum values are published by list_aigc_model_options()."
            )
        cls._coerce_enum(payload["aigc_type"], AigcModelType, "aigc_type")
        version_name = str(payload["version_name"])
        if len(version_name) > OPENAPI_VERSION_NAME_MAX_LENGTH:
            raise InvalidParameter(
                f"version_name must be at most {OPENAPI_VERSION_NAME_MAX_LENGTH} characters (got {len(version_name)})."
            )
        cls._validate_weight_files(payload["weight_files"])
        cls._validate_sample_images(payload["sample_images"])

    @staticmethod
    def _validate_weight_files(weight_files: Any) -> None:
        """Check every weight file reference carries a recognised suffix."""
        for entry in weight_files:
            path = entry.get("path_in_repo") if isinstance(entry, Mapping) else None
            if not path:
                raise InvalidParameter("each weight_files entry needs a non-empty 'path_in_repo'.")
            if not str(path).lower().endswith(WEIGHT_FILE_SUFFIXES):
                raise InvalidParameter(
                    f"weight file {path!r} does not have a recognised weight suffix. "
                    f"Supported suffixes: {', '.join(WEIGHT_FILE_SUFFIXES)}."
                )

    @staticmethod
    def _validate_sample_images(sample_images: Any) -> None:
        """Check sample images carry a URL and no retired ``text`` key."""
        for entry in sample_images:
            if not isinstance(entry, Mapping) or not entry.get("url"):
                raise InvalidParameter("each sample_images entry needs a non-empty 'url'.")
            if "text" in entry:
                raise InvalidParameter(
                    "sample_images does not accept 'text'; use 'prompt' and 'negative_prompt' instead."
                )

    def _resolve_version_id(self, repo_id: str, version_name: str) -> int:
        """Look up a version's numeric id by its name.

        The update endpoint addresses versions by numeric id, but callers think
        in version names, so the name is resolved here with one detail read.
        """
        detail = self.get_model(repo_id)
        versions = detail.get("versions")
        if not isinstance(versions, list):
            versions = []
        names = []
        for version in versions:
            if not isinstance(version, Mapping):
                continue
            name = version.get("version_name")
            names.append(str(name))
            if name == version_name and version.get("version_id") is not None:
                return int(version["version_id"])
        available = ", ".join(repr(n) for n in names) or "none"
        raise InvalidParameter(
            f"version_name={version_name!r} not found on {repo_id!r}. Available versions: {available}."
        )

    def list_repos(
        self,
        repo_type: RepoTypeLike,
        *,
        owner: str | None = None,
        search: str | None = None,
        sort: str | None = None,
        page_number: int = 1,
        page_size: int = 10,
        **filters: Any,
    ) -> PagedResult[RepoInfo]:
        """List repositories of the given type via OpenAPI.

        Parameters
        ----------
        repo_type : str or RepoType
            One of ``"model"``, ``"dataset"``, ``"studio"``, ``"skill"``, ``"mcp"``.
        owner : str, optional
            Restrict results to repositories owned by this user/org.
        search : str, optional
            Free-text search query.
        sort : str, optional
            Sort key understood by the upstream endpoint (e.g. ``"downloads"``).
        page_number : int, optional
            1-based page index. Default is 1.
        page_size : int, optional
            Items per page. Default is 10.
        **filters : Any
            Additional filter fields. ``None`` values are dropped.

        Returns
        -------
        PagedResult[RepoInfo]
            Paginated repository listing.

        Raises
        ------
        NotSupportedError
            When ``repo_type`` is not one of the listed values.

        Examples
        --------
        Browse public LLaMA models:

        >>> page = api.list_repos("model", search="llama", page_size=5)
        >>> page.total_count
        42
        >>> [r.repo_id for r in page.items]
        ['meta-llama/Llama-2-7b', ...]

        List datasets owned by an organisation:

        >>> api.list_repos("dataset", owner="my_org", page_number=2)
        """
        rt = self._normalize_repo_type(repo_type)
        clean_filters: dict[str, Any] = {k: v for k, v in filters.items() if v is not None}

        if rt is RepoType.MODEL:
            payload = self.openapi.list_models(
                search=search,
                owner=owner,
                sort=sort,
                page_number=page_number,
                page_size=page_size,
                filters=clean_filters or None,
            )
        elif rt is RepoType.DATASET:
            payload = self.openapi.list_datasets(
                search=search,
                owner=owner,
                sort=sort,
                page_number=page_number,
                page_size=page_size,
                filters=clean_filters or None,
            )
        elif rt is RepoType.SKILL:
            if owner:
                clean_filters.setdefault("owner", owner)
            payload = self.openapi.list_skills(
                search=search,
                page_number=page_number,
                page_size=page_size,
                filters=clean_filters or None,
            )
        elif rt is RepoType.MCP:
            payload = self.openapi.list_mcp_servers(
                search=search,
                page_number=page_number,
                page_size=page_size,
                filter=clean_filters or None,
            )
        elif rt is RepoType.STUDIO:
            payload = self.openapi.list_studios(
                search=search,
                owner=owner,
                sort=sort,
                page_number=page_number,
                page_size=page_size,
                **clean_filters,
            )
        else:  # pragma: no cover - defensive
            raise NotSupportedError(f"list_repos not supported for {rt}")

        items, total, page, size = self._extract_paged(payload)
        # MCP response omits page_number/page_size — use requested values.
        if rt is RepoType.MCP:
            page = page_number
            size = page_size
        infos = [self._repo_info_from_payload(item, rt) for item in items]
        # Determine collection key for OpenAPI-aligned to_dict() output
        _COLLECTION_KEYS = {
            RepoType.MODEL: "models",
            RepoType.DATASET: "datasets",
            RepoType.SKILL: "skills",
            RepoType.STUDIO: "studios",
            RepoType.MCP: "servers",
        }
        key = _COLLECTION_KEYS.get(rt, "items")
        return PagedResult(items=infos, total_count=total, page_number=page, page_size=size, collection_key=key)

    def delete_repo(self, repo_id: str, repo_type: RepoTypeLike) -> None:
        """Delete a repository.

        Needs a token carrying repository deletion permission; an admin-level
        token has been verified to work, while ordinary write permission does
        not guarantee it. Do not infer the permission from the token's name or
        kind. Deletion uses the legacy endpoint -- the current OpenAPI contract
        exposes no repository-deletion route.

        Parameters
        ----------
        repo_id : str
            Canonical ``owner/name`` identifier.
        repo_type : str or RepoType
            Repository type (``"model"``, ``"dataset"``, etc.).

        Raises
        ------
        AuthenticationError or InvalidParameter
            When the token lacks deletion permission. The Hub answers business
            code ``10010101003`` for models and ``10020301011`` for datasets,
            both saying the operation must be performed at
            https://modelscope.cn. Retrying with the same token will not help;
            use a token with deletion permission or the web console.

        Examples
        --------
        >>> api.delete_repo("alice/my-model", "model")
        """
        rt = self._normalize_repo_type(repo_type)
        self._parse_repo_id(repo_id)
        self.legacy.delete_repo(repo_id=repo_id, repo_type=str(rt))

    def repo_exists(self, repo_id: str, repo_type: RepoTypeLike) -> bool:
        """Return ``True`` iff the repository exists and is visible to the caller.

        This is a thin wrapper around :meth:`get_repo` that converts a
        :class:`NotExistError` into a boolean.

        Examples
        --------
        >>> api.repo_exists("alice/my-model", "model")
        True
        """
        try:
            self.get_repo(repo_id, repo_type)
            return True
        except NotExistError:
            return False

    def resolve_endpoint_for_read(
        self,
        repo_id: str,
        *,
        repo_type: RepoTypeLike = "model",
        token: str | None = None,
    ) -> str:
        """Resolve the best endpoint for read operations (download, list, get).

        1. If the endpoint was explicitly configured (via constructor arg,
           ``MODELSCOPE_ENDPOINT``, or the deprecated ``MODELSCOPE_DOMAIN``),
           trust the user's configuration and return it directly (no probe).
        2. If ``MODELSCOPE_PREFER_AI_SITE=true``, check ``.ai`` first, then
           fall back to ``.cn``.
        3. Otherwise (default), check ``.cn`` first, then fall back to ``.ai``.

        Parameters
        ----------
        token : str, optional
            Explicit token for the probe requests.  Falls back to the
            token stored in this instance's config.

        Returns
        -------
        str
            The endpoint URL where the repo exists.

        Raises
        ------
        NotExistError
            If the repo is not found on any checked endpoint.
        """
        from .constants import (
            DEFAULT_ENDPOINT,
            DEFAULT_INTL_ENDPOINT,
            ENV_PREFER_AI_SITE,
            _env_bool,
        )

        if self._config._endpoint_overridden:
            return self._config.endpoint or DEFAULT_ENDPOINT

        effective_token = token or self._config.token

        prefer_ai = _env_bool(ENV_PREFER_AI_SITE, False)
        primary = DEFAULT_INTL_ENDPOINT if prefer_ai else DEFAULT_ENDPOINT
        fallback = DEFAULT_ENDPOINT if prefer_ai else DEFAULT_INTL_ENDPOINT

        from ._download_control import _DownloadControl
        from .constants import REPO_TREE_PAGE_TIMEOUT_SECONDS

        def exists(endpoint: str) -> bool:
            from dataclasses import replace

            probe = HubApi(
                config=replace(self._config),
                endpoint=endpoint,
                token=effective_token,
                user_agent=self._user_agent_extra,
            )
            try:
                with _DownloadControl(
                    total_timeout=REPO_TREE_PAGE_TIMEOUT_SECONDS,
                    budget_label="Endpoint probe",
                    budget_env="MODELSCOPE_REPO_TREE_PAGE_TIMEOUT_SECONDS",
                ) as control:
                    with probe.openapi.read_context(control):
                        return probe.repo_exists(repo_id, repo_type)
            finally:
                probe.openapi.close()

        if exists(primary):
            return primary

        if exists(fallback):
            logger.warning(
                "Repo %s not found on %s, using %s instead.",
                repo_id,
                primary,
                fallback,
            )
            return fallback

        raise NotExistError(f"Repo {repo_id} not found on either {primary} or {fallback}")

    # ==================================================================
    # Files
    # ==================================================================
    def upload_file_to_openapi(self, file: str | Path | BinaryIO) -> str:
        """Upload a file (max 5 MiB) via OpenAPI and return the file ID.

        This is a generic upload not tied to any repository.  The returned
        ID can be used in subsequent API calls (e.g. ``skill_file`` when
        creating a skill).
        """
        data = self.openapi.upload_file(file=file)
        return data["id"]

    def upload_file(
        self,
        repo_id: str,
        repo_type: RepoTypeLike,
        path_or_fileobj: str | Path | bytes | BinaryIO,
        path_in_repo: str,
        *,
        commit_message: str | None = None,
        commit_description: str | None = None,
        revision: str | None = None,
        buffer_size_mb: int = 16,
        disable_tqdm: bool = False,
    ) -> dict:
        """Upload a single file to a repository.

        LFS files upload/reuse their blob first, then commit an LFS pointer.
        Normal files are committed directly with inline base64 content.
        LFS mode is determined by file suffix and size threshold.

        Parameters
        ----------
        repo_id : str
            Canonical ``owner/name`` identifier.
        repo_type : str or RepoType
            Repository type (``"model"``, ``"dataset"``, ...).
        path_or_fileobj : str, Path, bytes or BinaryIO
            Local path, raw bytes, or a binary file-like object.
        path_in_repo : str
            Destination path inside the repository.
        commit_message : str, optional
            Commit message. Defaults to ``"Upload file"``.
        commit_description : str, optional
            Extended commit description.
        revision : str, optional
            Branch to commit on. Defaults to ``"master"``.
        buffer_size_mb : int, optional
            Buffer size in MiB for reading file data. Default 16.
        disable_tqdm : bool, optional
            Disable progress bar. Default False.

        Returns
        -------
        dict
            Commit info from the server.

        Raises
        ------
        AuthenticationError
            When the token is missing or invalid.
        NotExistError
            When the target repository does not exist.

        Examples
        --------
        >>> api.upload_file(
        ...     "alice/llama-7b",
        ...     repo_type="model",
        ...     path_or_fileobj="./pytorch_model.bin",
        ...     path_in_repo="pytorch_model.bin",
        ...     commit_message="Add fine-tuned weights",
        ... )
        """
        rt = self._normalize_repo_type(repo_type)
        return self.uploader.upload_file(
            repo_id=repo_id,
            repo_type=str(rt),
            path_or_fileobj=path_or_fileobj,
            path_in_repo=path_in_repo,
            commit_message=commit_message or "Upload file",
            commit_description=commit_description,
            revision=revision or "master",
            buffer_size_mb=buffer_size_mb,
            disable_tqdm=disable_tqdm,
        )

    def upload_folder(
        self,
        repo_id: str,
        repo_type: RepoTypeLike,
        folder_path: str | Path,
        *,
        path_in_repo: str = "",
        commit_message: str | None = None,
        commit_description: str | None = None,
        revision: str | None = None,
        allow_patterns: list[str] | None = None,
        ignore_patterns: list[str] | None = None,
        max_workers: int | None = None,
        use_cache: bool | None = None,
        disable_tqdm: bool = False,
        sync_remote_repo: bool = False,
        tracker_path: str | Path | None = None,
        progress_callback: Callable[[dict], None] | None = None,
    ) -> dict | list[dict] | None:
        """Upload an entire folder to a repository with resumable support.

        Files are walked recursively from ``folder_path`` and uploaded in
        parallel with adaptive batching, per-file retry, and ReAct progressive
        retry fallback.

        Parameters
        ----------
        repo_id : str
            Canonical ``owner/name`` identifier.
        repo_type : str or RepoType
            Repository type.
        folder_path : str or Path
            Local directory whose contents will be uploaded.
        path_in_repo : str, optional
            Destination prefix inside the repository. Defaults to the repo root.
        commit_message : str, optional
            Commit message. Defaults to ``"Upload folder"``.
        commit_description : str, optional
            Extended commit description.
        revision : str, optional
            Branch to commit on. Defaults to ``"master"``.
        allow_patterns : list of str, optional
            If given, only files matching at least one pattern are uploaded.
        ignore_patterns : list of str, optional
            Files matching any pattern are skipped.
        max_workers : int, optional
            Concurrency for parallel uploads. Defaults to adaptive.
        use_cache : bool, optional
            Use resumable upload caching. When omitted, read
            ``MODELSCOPE_UPLOAD_CACHE_ENABLED``. Explicit ``True`` or ``False``
            overrides the environment configuration.
        disable_tqdm : bool, optional
            Disable progress bars. Default False.
        sync_remote_repo : bool, optional
            If True, delete remote files that are not present locally after
            a successful upload (sync semantics). Default False.
        tracker_path : str or Path, optional
            Where to keep the resumable-upload cache. Defaults to
            ``.ms_upload_cache`` inside ``folder_path``. Point this outside the
            uploaded tree when ``folder_path`` is a staging directory that gets
            discarded between runs, so resume state survives.
        progress_callback : callable, optional
            Called with one dict per batch outcome, carrying ``event``
            (``"batch_committed"`` or ``"batch_failed"``), ``batch_index``,
            ``num_batches``, ``batch_files``, ``batch_bytes``,
            ``committed_files``, ``committed_bytes``, ``total_files``,
            ``total_bytes``, ``skipped_files``, ``elapsed`` and ``error``.
            Exceptions raised by the callback are logged and swallowed.

        Returns
        -------
        None
            If all files were already committed (nothing to do).
        dict
            If only one batch was committed.
        list of dict
            If multiple batches were committed.

        Examples
        --------
        >>> api.upload_folder(
        ...     "alice/llama-7b",
        ...     repo_type="model",
        ...     folder_path="./checkpoint-1000",
        ...     ignore_patterns=["*.optim", "events.out.*"],
        ...     max_workers=8,
        ... )
        """
        rt = self._normalize_repo_type(repo_type)
        return self.uploader.upload_folder(
            repo_id=repo_id,
            repo_type=str(rt),
            folder_path=folder_path,
            path_in_repo=path_in_repo,
            commit_message=commit_message or "Upload folder",
            commit_description=commit_description,
            revision=revision or "master",
            allow_patterns=allow_patterns,
            ignore_patterns=ignore_patterns,
            max_workers=max_workers,
            use_cache=use_cache,
            disable_tqdm=disable_tqdm,
            sync_remote_repo=sync_remote_repo,
            tracker_path=tracker_path,
            progress_callback=progress_callback,
        )

    def download_file(
        self,
        repo_id: str,
        repo_type: RepoTypeLike,
        file_path: str,
        *,
        revision: str | None = None,
        cache_dir: str | Path | None = None,
        local_dir: str | Path | None = None,
        force: bool = False,
        expected_sha256: str | None = None,
        local_files_only: bool = False,
        user_agent: dict | str | None = None,
        file_size: int | None = None,
    ) -> Path:
        """Download a single file from a repository.

        The file is fetched into the local cache and a path pointing at the
        cached blob is returned. Subsequent calls reuse the cached copy
        unless ``force=True``. A standalone file download sends no
        ``snapshot-identifier``; the dataset service uses fractional per-file
        counting for these requests. Model counting uses separate server logic.

        Parameters
        ----------
        repo_id : str
            Canonical ``owner/name`` identifier.
        repo_type : str or RepoType
            Repository type.
        file_path : str
            Path of the file inside the repository.
        revision : str, optional
            Branch, tag or commit SHA. Defaults to ``"master"``.
        cache_dir : str or Path, optional
            Override the default cache directory.
        local_dir : str or Path, optional
            When set, download directly into this directory instead of cache.
        force : bool, optional
            Re-download even if a cached copy exists. Default is ``False``.
        expected_sha256 : str, optional
            When provided, verify downloaded file hash and use it for
            cache hit validation. On mismatch, re-download up to 3 times.
        local_files_only : bool, optional
            When ``True``, return the cached path without network access.
            Raises :class:`CacheNotFound` if the file is not cached.
        user_agent : dict, str or None, optional
            Custom user-agent info appended to the default UA string.
        file_size : int, optional
            Expected size in bytes, e.g. from a file listing. The download is
            rejected when the server delivers a different size, and files
            larger than the parallel threshold use ranged parallel streams.

        Returns
        -------
        Path
            Absolute path to the downloaded file on disk.

        Raises
        ------
        NotExistError
            When the file or repository does not exist.
        FileIntegrityError
            When the content keeps failing ``expected_sha256`` or (as
            :class:`FileSizeMismatchError`) ``file_size``.

        Examples
        --------
        >>> path = api.download_file(
        ...     "alice/llama-7b",
        ...     repo_type="model",
        ...     file_path="config.json",
        ... )
        >>> path.read_text()[:30]
        '{\n  "architectures": [\n    "Ll'
        """
        rt = self._normalize_repo_type(repo_type)
        if rt is RepoType.STUDIO:
            raise NotSupportedError(
                "File download is not supported for studio repositories. "
                "Studios are application containers without a file listing API. "
                f"To access studio source code, use: git clone https://modelscope.cn/studios/{repo_id}.git"
            )
        return self.downloader.download_file(
            repo_id=repo_id,
            repo_type=str(rt),
            file_path=file_path,
            revision=revision,
            cache_dir=Path(cache_dir) if cache_dir else None,
            local_dir=Path(local_dir) if local_dir else None,
            force=force,
            expected_sha256=expected_sha256,
            local_files_only=local_files_only,
            user_agent=user_agent,
            file_size=file_size,
        )

    def download_repo_report(
        self,
        repo_id: str,
        repo_type: RepoTypeLike,
        *,
        revision: str | None = None,
        cache_dir: str | Path | None = None,
        local_dir: str | Path | None = None,
        allow_patterns: list[str] | None = None,
        ignore_patterns: list[str] | None = None,
        max_workers: int = 4,
        file_list: Iterable[dict] | None = None,
        tracker_path: str | Path | None = None,
        retry_failed: bool = False,
        retry_policy: DownloadRetryPolicy | None = None,
        user_agent: dict | str | None = None,
        progress_callbacks: list[type[ProgressCallback]] | None = None,
    ) -> DownloadReport:
        """Download known files despite ordinary failures; never label partial data complete.

        Unlike download_repo, file failures return a PARTIAL report instead of
        raising an aggregate exception. The default hidden JSON tracker is in
        cache_dir/.download_state, outside repository contents. The single JSON
        combines exceptional files, failed pages, and the latest call's summary,
        scoped to endpoint/repo/revision/
        output so batches share recovery hints. Actual size/hash validation
        overrides stale failure hints; otherwise retry_failed=True or changed
        metadata resets them. Missing/corrupt hints trigger bounded fresh
        recovery, not false success. Inspect report.state_warnings for issues.

        file_list accepts an iterable of legacy Path/Size/Sha256 entries. Without
        it, datasets are enumerated page by page with bounded backpressure.
        Use a pinned revision or an authoritative manifest for migration jobs.
        Inspect report.complete and report.iter_files('VERIFIED') before using
        the downloaded data. report.report_path equals report.tracker_path;
        its JSON has the latest summary under 'report', without per-run files.
        iter_files streams temporary results owned by the live report; call
        report.close() after consumption. Persisted hints cannot prove success.
        Every file request of a task carries one ``snapshot-identifier`` kept in
        the same JSON: reruns of an unfinished task (PARTIAL or CANCELLED) reuse
        it, and the run after a COMPLETE one starts a new task.
        """
        return self.downloader.download_repo_report(
            repo_id,
            str(self._normalize_repo_type(repo_type)),
            revision=revision,
            cache_dir=Path(cache_dir) if cache_dir else None,
            local_dir=Path(local_dir) if local_dir else None,
            allow_patterns=allow_patterns,
            ignore_patterns=ignore_patterns,
            max_workers=max_workers,
            file_list=file_list,
            tracker_path=Path(tracker_path) if tracker_path else None,
            retry_failed=retry_failed,
            retry_policy=retry_policy,
            user_agent=user_agent,
            progress_callbacks=progress_callbacks,
        )

    def download_repo(
        self,
        repo_id: str,
        repo_type: RepoTypeLike,
        *,
        revision: str | None = None,
        cache_dir: str | Path | None = None,
        local_dir: str | Path | None = None,
        allow_patterns: list[str] | None = None,
        ignore_patterns: list[str] | None = None,
        max_workers: int = 4,
        local_files_only: bool = False,
        user_agent: dict | str | None = None,
        progress_callbacks: list[type[ProgressCallback]] | None = None,
        file_list: list[dict] | None = None,
    ) -> Path:
        """Download an entire repository snapshot.

        All files at the given ``revision`` are fetched into the local cache
        in parallel. The returned path is the snapshot root directory. Each
        call is one logical snapshot download: all of its file requests,
        including retries, resumed transfers and range parts, carry the same
        ``snapshot-identifier`` for dataset counting within the server's
        two-hour deduplication window. Cached files issue no download requests.

        Parameters
        ----------
        repo_id : str
            Canonical ``owner/name`` identifier.
        repo_type : str or RepoType
            Repository type.
        revision : str, optional
            Branch, tag or commit SHA. Defaults to ``"master"``.
        cache_dir : str or Path, optional
            Override the default cache directory.
        local_dir : str or Path, optional
            When set, download directly into this directory instead of cache.
        allow_patterns : list of str, optional
            If given, only matching files are downloaded.
        ignore_patterns : list of str, optional
            Matching files are skipped.
        max_workers : int, optional
            Concurrency for parallel downloads. Default is 4.
        local_files_only : bool, optional
            When ``True``, return the cached snapshot path without network.
        user_agent : dict, str or None, optional
            Custom user-agent info for download headers.
        progress_callbacks : list of ProgressCallback subclasses, optional
            Callback *classes* (not instances); each is instantiated per file
            to report byte-level download progress.
        file_list : list of dict, optional
            Previously fetched legacy file entries (Path, Size, Sha256). When
            provided, listing requests are skipped. The caller must ensure the
            entries belong to the same repository and revision; filters still apply.

        Returns
        -------
        Path
            Absolute path to the snapshot/local directory.

        Raises
        ------
        FileDownloadError
            When any file failed after all files were attempted. Completed
            files are kept, so calling again fetches only the failed ones;
            ``failed_files`` maps each failed path to its error.

        Examples
        --------
        Download only the tokenizer assets of a model:

        >>> root = api.download_repo(
        ...     "alice/llama-7b",
        ...     repo_type="model",
        ...     allow_patterns=["tokenizer*", "*.json"],
        ...     max_workers=8,
        ... )
        >>> sorted(p.name for p in root.iterdir())
        ['config.json', 'tokenizer.json', 'tokenizer_config.json']
        """
        rt = self._normalize_repo_type(repo_type)
        if rt is RepoType.STUDIO:
            raise NotSupportedError(
                "File download is not supported for studio repositories. "
                "Studios are application containers without a file listing API. "
                f"To access studio source code, use: git clone https://modelscope.cn/studios/{repo_id}.git"
            )
        return self.downloader.download_repo(
            repo_id=repo_id,
            repo_type=str(rt),
            revision=revision,
            cache_dir=Path(cache_dir) if cache_dir else None,
            local_dir=Path(local_dir) if local_dir else None,
            allow_patterns=allow_patterns,
            ignore_patterns=ignore_patterns,
            max_workers=max_workers,
            local_files_only=local_files_only,
            user_agent=user_agent,
            progress_callbacks=progress_callbacks,
            file_list=file_list,
        )

    def list_repo_files(
        self,
        repo_id: str,
        repo_type: RepoTypeLike,
        *,
        revision: str | None = None,
        recursive: bool = True,
    ) -> list[FileInfo]:
        """List files inside a repository (legacy — no OpenAPI equivalent).

        Parameters
        ----------
        repo_id : str
            Canonical ``owner/name`` identifier.
        repo_type : str or RepoType
            Repository type.
        revision : str, optional
            Branch, tag or commit SHA. Defaults to ``"master"``.
        recursive : bool, optional
            Walk subdirectories recursively. Default is ``True``.

        Returns
        -------
        list of FileInfo
            File metadata entries (path, size, blob id, last modified, ...).

        Examples
        --------
        >>> files = api.list_repo_files("alice/llama-7b", "model")
        >>> [f.path for f in files][:3]
        ['README.md', 'config.json', 'pytorch_model.bin']
        """
        rt = self._normalize_repo_type(repo_type)
        raw = self.legacy.list_repo_files(
            repo_id=repo_id,
            repo_type=str(rt),
            revision=revision or "master",
            recursive=recursive,
        )
        files: list[FileInfo] = []
        for item in raw:
            normalised = {
                "path": item.get("Path") or item.get("path") or item.get("Name") or "",
                "size": int(item.get("Size") or item.get("size") or 0),
                "blob_id": item.get("BlobId") or item.get("blob_id") or item.get("Sha256"),
                "sha256": item.get("Sha256") or item.get("sha256"),
                "type": item.get("Type") or item.get("type") or "blob",
                "last_modified": item.get("CommittedDate") or item.get("last_modified"),
                "lfs": item.get("Lfs") or item.get("lfs"),
            }
            files.append(FileInfo.from_dict(normalised))
        return files

    def delete_files(
        self,
        repo_id: str,
        repo_type: RepoTypeLike,
        file_paths: Iterable[str] | str | None = None,
        *,
        delete_patterns: Iterable[str] | str | None = None,
        commit_message: str | None = None,
        revision: str | None = None,
    ) -> dict:
        """Delete repository files selected by paths or glob patterns.

        The direct repository DELETE endpoints reject API-token authentication.
        This method resolves optional glob patterns against the remote file list,
        then sends commit ``delete`` actions through the same supported write
        path as :meth:`upload_file` and :meth:`upload_folder`.

        Parameters
        ----------
        repo_id : str
            Canonical ``owner/name`` identifier.
        repo_type : str or RepoType
            Repository type.
        file_paths : iterable of str or str, optional
            Explicit repository-relative paths to remove.
        delete_patterns : iterable of str or str, optional
            Glob patterns matched against remote file paths. For example,
            ``"*.json"`` matches JSON files at any repository depth.
        commit_message : str, optional
            Message for the delete commit. Defaults to ``"Delete files"``.
        revision : str, optional
            Branch to delete from. Defaults to ``"master"``.

        Returns
        -------
        dict
            Summary with ``deleted_files``, ``failed_files``, and ``total_files``.
            A pattern with no remote matches returns an empty successful summary.
        """
        rt = self._normalize_repo_type(repo_type)
        paths = self._normalize_delete_values(file_paths, "file_paths")
        patterns = self._normalize_delete_values(delete_patterns, "delete_patterns")
        if not paths and not patterns:
            raise InvalidParameter("Provide at least one file path or delete pattern.")

        resolved_revision = revision or "master"
        if patterns:
            remote_paths = [
                file.path
                for file in self.list_repo_files(
                    repo_id,
                    rt,
                    revision=resolved_revision,
                    recursive=True,
                )
                if file.path and file.type != "tree"
            ]
            paths.extend(
                path for path in remote_paths if any(fnmatch.fnmatchcase(path, pattern) for pattern in patterns)
            )

        paths = list(dict.fromkeys(paths))
        if not paths:
            return {
                "deleted_files": [],
                "failed_files": [],
                "total_files": 0,
            }

        return self.uploader.delete_files(
            repo_id=repo_id,
            repo_type=str(rt),
            file_paths=paths,
            commit_message=commit_message or "Delete files",
            revision=resolved_revision,
        )

    @staticmethod
    def _normalize_delete_values(
        values: Iterable[str] | str | None,
        parameter_name: str,
    ) -> list[str]:
        """Normalize a delete path or glob-pattern argument."""
        if values is None:
            return []
        raw_values = [values] if isinstance(values, str) else list(values)
        normalized: list[str] = []
        for value in raw_values:
            if not isinstance(value, str):
                raise InvalidParameter(f"{parameter_name} must contain only strings.")
            if value:
                normalized.append(value)
        return normalized

    # ==================================================================
    # Versioning
    # ==================================================================
    def list_repo_revisions(self, repo_id: str, repo_type: RepoTypeLike) -> list[dict]:
        """Return branches and tags of a repository (legacy).

        Examples
        --------
        >>> revs = api.list_repo_revisions("alice/llama-7b", "model")
        >>> [r["name"] for r in revs]
        ['master', 'v1.0', 'experimental']
        """
        rt = self._normalize_repo_type(repo_type)
        return self.legacy.list_revisions(repo_id=repo_id, repo_type=str(rt))

    def create_repo_tag(
        self,
        repo_id: str,
        repo_type: RepoTypeLike,
        tag: str,
        *,
        revision: str | None = None,
    ) -> dict:
        """Create a tag pointing at ``revision`` (defaults to ``master``).

        Examples
        --------
        >>> api.create_repo_tag("alice/llama-7b", "model", "v1.0")
        """
        rt = self._normalize_repo_type(repo_type)
        return self.legacy.create_tag(
            repo_id=repo_id,
            repo_type=str(rt),
            tag=tag,
            revision=revision or "master",
        )

    # ==================================================================
    # Lifecycle (Studio / MCP)
    # ==================================================================
    def deploy_repo(
        self,
        repo_id: str,
        repo_type: RepoTypeLike = RepoType.STUDIO,
        *,
        payload: Mapping[str, Any] | None = None,
    ) -> dict:
        """Deploy a Studio space or an MCP server.

        Parameters
        ----------
        repo_id : str
            For Studios, an ``owner/name`` pair. For MCP servers, the
            server identifier accepted by the OpenAPI surface.
        repo_type : str or RepoType, optional
            ``"studio"`` (default) or ``"mcp"``.
        payload : Mapping, optional
            Deployment configuration forwarded verbatim to the backend
            (hardware tier, env vars, ...).

        Returns
        -------
        dict
            Deployment response payload (deployment id, status URL, ...).

        Raises
        ------
        NotSupportedError
            When ``repo_type`` is neither ``"studio"`` nor ``"mcp"``.

        Examples
        --------
        Deploy a Studio space on a GPU instance:

        >>> api.deploy_repo(
        ...     "alice/chat-demo",
        ...     repo_type="studio",
        ...     payload={"instance_type": "GPU-A10", "min_replicas": 1},
        ... )
        """
        rt = self._normalize_repo_type(repo_type)
        if rt is RepoType.STUDIO:
            owner, name = self._parse_repo_id(repo_id)
            return self.openapi.deploy_studio(owner, name, payload)
        if rt is RepoType.MCP:
            return self.openapi.deploy_mcp_server(repo_id, payload)
        raise NotSupportedError(f"deploy_repo is not supported for repo_type={rt.value!r}.")

    def stop_repo(
        self,
        repo_id: str,
        repo_type: RepoTypeLike = RepoType.STUDIO,
    ) -> dict:
        """Stop a running Studio or undeploy an MCP server.

        Examples
        --------
        >>> api.stop_repo("alice/chat-demo", repo_type="studio")
        """
        rt = self._normalize_repo_type(repo_type)
        if rt is RepoType.STUDIO:
            owner, name = self._parse_repo_id(repo_id)
            return self.openapi.stop_studio(owner, name)
        if rt is RepoType.MCP:
            return self.openapi.undeploy_mcp_server(repo_id)
        raise NotSupportedError(f"stop_repo is not supported for repo_type={rt.value!r}.")

    def get_repo_logs(
        self,
        repo_id: str,
        repo_type: RepoTypeLike = RepoType.STUDIO,
        *,
        log_type: str = "run",
        page_num: int = 1,
        page_size: int = 20,
        keyword: str | None = None,
        start_timestamp: int | None = None,
        end_timestamp: int | None = None,
    ) -> dict:
        """Fetch paginated runtime/build logs for a Studio space.

        Parameters
        ----------
        repo_id : str
            Studio identifier in ``owner/name`` form.
        repo_type : str or RepoType, optional
            Must be ``"studio"``. Defaults to :class:`RepoType.STUDIO`.
        log_type : str, optional
            Either ``"run"`` (default) or ``"build"``.
        page_num : int, optional
            1-based page index. Default is 1.
        page_size : int, optional
            Lines per page. Default is 20.
        keyword : str, optional
            Filter logs containing this substring.
        start_timestamp, end_timestamp : int, optional
            Unix timestamps (seconds) bounding the log window.

        Returns
        -------
        dict
            Paginated log payload.

        Raises
        ------
        NotSupportedError
            When ``repo_type`` is not ``"studio"``.

        Examples
        --------
        >>> logs = api.get_repo_logs(
        ...     "alice/chat-demo",
        ...     log_type="run",
        ...     keyword="ERROR",
        ...     page_size=50,
        ... )
        """
        rt = self._normalize_repo_type(repo_type)
        if rt is not RepoType.STUDIO:
            raise NotSupportedError(f"get_repo_logs is currently only supported for studio (got {rt.value!r}).")
        owner, name = self._parse_repo_id(repo_id)
        return self.openapi.get_studio_logs(
            owner,
            name,
            log_type,
            page_num=page_num,
            page_size=page_size,
            keyword=keyword,
            start_timestamp=start_timestamp,
            end_timestamp=end_timestamp,
        )

    def update_repo_settings(
        self,
        repo_id: str,
        repo_type: RepoTypeLike,
        **settings: Any,
    ) -> dict:
        """Update a repository's general settings.

        Supported for ``model``, ``dataset``, ``studio`` and ``skill``. Only the
        keys you pass are changed; for models and datasets an explicit ``None``
        clears metadata fields, while None for visibility/gated_mode leaves
        those controls unchanged. Zone membership is not a setting -- use
        :meth:`set_model_category` / :meth:`set_dataset_category` for that.

        Parameters
        ----------
        repo_id : str
            Canonical ``owner/name`` identifier.
        repo_type : str or RepoType
            ``"model"``, ``"dataset"``, ``"studio"`` or ``"skill"``.
        **settings : Any
            Setting key/value pairs forwarded to the backend. For models and
            datasets: ``display_name``, ``license``, ``visibility``, ``description``
            and ``task`` (models only). ``gated_mode`` remains a boolean switch:
            True enables application access, False disables it, None leaves it
            unchanged. Omitted visibility with either explicit boolean implies
            private; explicit public takes precedence and ignores the switch.
            High-level visibility accepts the historical integer enum/labels,
            not the native OpenAPI 'gated' access-mode string.

        Returns
        -------
        dict
            Updated settings payload.

        Raises
        ------
        NotSupportedError
            When ``repo_type`` has no settings endpoint, or when a setting the
            endpoint cannot change is requested (notably ``login_required``).

        Examples
        --------
        >>> api.update_repo_settings(
        ...     "alice/chat-demo",
        ...     repo_type="studio",
        ...     visibility="public",
        ...     hardware="GPU-A10",
        ... )
        >>> api.update_repo_settings(
        ...     "alice/rna-seq", "dataset", visibility="private",
        ...     gated_mode=True,
        ... )
        >>> api.update_repo_settings("alice/rna-seq", "dataset", gated_mode=False)
        """
        self._reject_removed_gating_parameters(settings)
        rt = self._normalize_repo_type(repo_type)
        owner, name = self._parse_repo_id(repo_id)
        if rt is RepoType.STUDIO:
            return self.openapi.update_studio_settings(owner, name, _normalise_studio_fields(settings))
        if rt is RepoType.SKILL:
            return self.openapi.update_skill_settings(owner, name, settings)
        if rt is RepoType.DATASET:
            payload = self._repo_settings_payload(rt, settings)
            data = self.openapi.update_dataset_settings(owner, name, payload)
            return dict(data) if isinstance(data, Mapping) else {}
        if rt is RepoType.MODEL:
            payload = self._repo_settings_payload(rt, settings)
            data = self.openapi.update_model_settings(owner, name, payload)
            return dict(data) if isinstance(data, Mapping) else {}
        raise NotSupportedError(f"update_repo_settings is not supported for repo_type={rt.value!r}.")

    @classmethod
    def _repo_settings_payload(cls, rt: RepoType, settings: Mapping[str, Any]) -> dict[str, Any]:
        """Adapt the historical boolean switch and visibility to OpenAPI.

        None leaves the switch/visibility unchanged. True/False with omitted
        visibility implies private. Native strings belong to the low-level
        OpenAPI payload, not to this high-level boolean parameter.
        """
        cls._reject_removed_gating_parameters(settings)
        payload = dict(settings)
        unsupported = sorted(_UNSETTABLE_FIELDS & set(payload))
        if unsupported:
            raise NotSupportedError(
                f"{', '.join(unsupported)} cannot be changed through update_repo_settings: "
                f"the {rt.value} settings endpoint does not accept it. "
                f"It is reported read-only by get_{rt.value}()."
            )
        switch = payload.pop("gated_mode", None)
        if switch is not None and not isinstance(switch, bool):
            raise InvalidParameter("gated_mode must be True, False or None, not an approval-policy string.")
        raw_visibility = payload.pop("visibility", None)
        visibility = cls._normalize_visibility(raw_visibility)
        if visibility is not None:
            if visibility not in (int(Visibility.PRIVATE), int(Visibility.PUBLIC)):
                raise InvalidParameter(
                    f"visibility={raw_visibility!r} is not supported by the {rt.value} settings endpoint; "
                    "there is no equivalent legacy settings endpoint."
                )
            wire_visibility = cls._openapi_visibility(rt, visibility)
            assert wire_visibility is not None
            payload["visibility"] = wire_visibility.value
        if switch is not None:
            if visibility is None:
                visibility = int(Visibility.PRIVATE)
                payload["visibility"] = RepoVisibility.PRIVATE.value
            if visibility == int(Visibility.PRIVATE):
                if switch:
                    # OpenAPI represents application access as a wire access mode.
                    payload["visibility"] = RepoVisibility.GATED.value
                    payload["gated_mode"] = "auto"
                else:
                    payload["visibility"] = RepoVisibility.PRIVATE.value
            else:
                logger.warning("gated_mode is only effective when visibility is PRIVATE, ignored.")
        return payload

    # ==================================================================
    # Secrets
    # ==================================================================
    def list_secrets(self, repo_id: str, repo_type: RepoTypeLike = RepoType.STUDIO) -> list[dict]:
        """List the keys of the secrets attached to a Studio.

        Values are never disclosed by the endpoint. Use :meth:`list_variables`
        for the plaintext counterpart, whose values are returned.

        Examples
        --------
        >>> api.list_secrets("alice/chat-demo")
        [{'key': 'OPENAI_API_KEY'}, ...]
        """
        rt = self._normalize_repo_type(repo_type)
        if rt is not RepoType.STUDIO:
            raise NotSupportedError(f"Secret management is only supported for studio (got {rt.value!r}).")
        owner, name = self._parse_repo_id(repo_id)
        data = self.openapi.list_studio_secrets(owner, name)
        return _unwrap_list(data, ("secrets", "items", "list"))

    def add_secret(
        self,
        repo_id: str,
        key: str,
        value: str,
        repo_type: RepoTypeLike = RepoType.STUDIO,
    ) -> dict:
        """Add a new secret to a Studio.

        Examples
        --------
        >>> api.add_secret("alice/chat-demo", "OPENAI_API_KEY", "sk-...")
        """
        rt = self._normalize_repo_type(repo_type)
        if rt is not RepoType.STUDIO:
            raise NotSupportedError("Only studio secrets are supported.")
        owner, name = self._parse_repo_id(repo_id)
        return self.openapi.add_studio_secret(owner, name, key, value)

    def update_secret(
        self,
        repo_id: str,
        key: str,
        value: str,
        repo_type: RepoTypeLike = RepoType.STUDIO,
    ) -> dict:
        """Update an existing secret value.

        Examples
        --------
        >>> api.update_secret("alice/chat-demo", "OPENAI_API_KEY", "sk-new-...")
        """
        rt = self._normalize_repo_type(repo_type)
        if rt is not RepoType.STUDIO:
            raise NotSupportedError("Only studio secrets are supported.")
        owner, name = self._parse_repo_id(repo_id)
        return self.openapi.update_studio_secret(owner, name, key, value)

    def delete_secret(
        self,
        repo_id: str,
        key: str,
        repo_type: RepoTypeLike = RepoType.STUDIO,
    ) -> dict:
        """Delete a secret from a Studio.

        Examples
        --------
        >>> api.delete_secret("alice/chat-demo", "OPENAI_API_KEY")
        """
        rt = self._normalize_repo_type(repo_type)
        if rt is not RepoType.STUDIO:
            raise NotSupportedError("Only studio secrets are supported.")
        owner, name = self._parse_repo_id(repo_id)
        return self.openapi.delete_studio_secret(owner, name, key)

    # ==================================================================
    # Plaintext variables
    #
    # The counterpart to the secrets block above. Same shape, different
    # disclosure: a variable's value is publicly readable, a secret's is not.
    # ==================================================================
    def list_variables(self, repo_id: str, repo_type: RepoTypeLike = RepoType.STUDIO) -> list[dict]:
        """List plaintext environment variables attached to a Studio.

        Unlike :meth:`list_secrets`, the values are returned too -- plaintext
        variables are publicly visible by design.

        Examples
        --------
        >>> api.list_variables("alice/chat-demo")
        [{'key': 'MODEL_NAME', 'value': 'Qwen2.5-7B'}, ...]
        """
        rt = self._normalize_repo_type(repo_type)
        if rt is not RepoType.STUDIO:
            raise NotSupportedError(f"Variable management is only supported for studio (got {rt.value!r}).")
        owner, name = self._parse_repo_id(repo_id)
        data = self.openapi.list_studio_variables(owner, name)
        return _unwrap_list(data, ("variables", "items", "list"))

    def add_variable(
        self,
        repo_id: str,
        key: str,
        value: str,
        repo_type: RepoTypeLike = RepoType.STUDIO,
    ) -> dict:
        """Add a plaintext environment variable to a Studio.

        Both key and value are publicly visible; use :meth:`add_secret` for
        anything sensitive.

        Examples
        --------
        >>> api.add_variable("alice/chat-demo", "MODEL_NAME", "Qwen2.5-7B")
        """
        rt = self._normalize_repo_type(repo_type)
        if rt is not RepoType.STUDIO:
            raise NotSupportedError("Only studio variables are supported.")
        owner, name = self._parse_repo_id(repo_id)
        return self.openapi.add_studio_variable(owner, name, key, value)

    def update_variable(
        self,
        repo_id: str,
        key: str,
        value: str,
        repo_type: RepoTypeLike = RepoType.STUDIO,
    ) -> dict:
        """Update an existing plaintext variable's value.

        Examples
        --------
        >>> api.update_variable("alice/chat-demo", "MODEL_NAME", "Qwen2.5-14B")
        """
        rt = self._normalize_repo_type(repo_type)
        if rt is not RepoType.STUDIO:
            raise NotSupportedError("Only studio variables are supported.")
        owner, name = self._parse_repo_id(repo_id)
        return self.openapi.update_studio_variable(owner, name, key, value)

    def delete_variable(
        self,
        repo_id: str,
        key: str,
        repo_type: RepoTypeLike = RepoType.STUDIO,
    ) -> dict:
        """Delete a plaintext variable from a Studio.

        Examples
        --------
        >>> api.delete_variable("alice/chat-demo", "MODEL_NAME")
        """
        rt = self._normalize_repo_type(repo_type)
        if rt is not RepoType.STUDIO:
            raise NotSupportedError("Only studio variables are supported.")
        owner, name = self._parse_repo_id(repo_id)
        return self.openapi.delete_studio_variable(owner, name, key)

    # ==================================================================
    # Studio resource discovery
    # ==================================================================
    def list_studio_hardware(
        self,
        *,
        sdk_type: str | None = None,
        repo_id: str | None = None,
    ) -> list[dict]:
        """List the hardware tiers a Studio may be deployed on.

        Answers the question ``--hardware`` used to leave to guesswork. Anonymous
        callers see the default free tier; authenticated callers also see paid
        tiers with prices, which are selected as ``paid/<instance_type>``.

        Parameters
        ----------
        sdk_type : str, optional
            Keep only tiers supporting this SDK type.
        repo_id : str, optional
            Scope the free tiers to what this ``owner/name`` space may use.

        Examples
        --------
        >>> [h["name"] for h in api.list_studio_hardware(sdk_type="gradio")]
        ['CPU basic 2 vCPU 16GB', ...]
        """
        data = self.openapi.list_studio_hardware(sdk_type=sdk_type, studio=repo_id)
        return _unwrap_list(data, ("hardware", "items", "list"))

    def list_studio_base_images(self) -> list[dict]:
        """List the base images available to Studio spaces.

        Examples
        --------
        >>> api.list_studio_base_images()
        [{'name': 'ubuntu22.04-py311-torch2.3.1', 'tag': '...'}, ...]
        """
        data = self.openapi.list_studio_base_images()
        return _unwrap_list(data, ("base_images", "items", "list"))

    def list_studio_sdk_versions(self, *, sdk_type: str | None = None) -> list[dict]:
        """List the SDK versions available to Studio spaces.

        Only ``sdk_type="gradio"`` yields versions; the other SDK types (and
        omitting it) return an empty list.

        Examples
        --------
        >>> [v["version"] for v in api.list_studio_sdk_versions(sdk_type="gradio")]
        ['4.44.1', ...]
        """
        data = self.openapi.list_studio_sdk_versions(sdk_type=sdk_type)
        return _unwrap_list(data, ("sdk_versions", "items", "list"))

    # ==================================================================
    # MCP convenience wrappers
    # ==================================================================
    def list_mcp_servers(
        self,
        *,
        search: str | None = None,
        page_number: int = 1,
        page_size: int = 10,
        filter: Mapping[str, Any] | None = None,
        **extra: Any,
    ) -> PagedResult[dict]:
        """List MCP servers via the OpenAPI surface.

        Parameters
        ----------
        search : str, optional
            Free-text search query.
        page_number : int, optional
            1-based page index. Default is 1.
        page_size : int, optional
            Items per page. Default is 10.
        filter : Mapping, optional
            Nested MCP filter object.
        **extra : Any
            Additional filter fields. ``None`` values are dropped.

        Returns
        -------
        PagedResult[dict]
            Paginated MCP server listing.

        Examples
        --------
        >>> page = api.list_mcp_servers(search="weather", page_size=5)
        >>> page.total_count
        12
        """
        payload = self.openapi.list_mcp_servers(
            search=search,
            page_number=page_number,
            page_size=page_size,
            filter=filter,
            extra={k: v for k, v in extra.items() if v is not None} or None,
        )
        items, total, _page, _size = self._extract_paged(payload)
        # The MCP service currently omits page_number/page_size in its response.
        # The request values are authoritative, exactly as in list_repos("mcp"),
        # so callers can reliably tell which page they received.
        return PagedResult(
            items=list(items),
            total_count=total,
            page_number=page_number,
            page_size=page_size,
        )

    def list_operational_mcp_servers(self) -> PagedResult[dict]:
        """List the MCP servers the caller currently has hosted.

        Returns the same :class:`PagedResult` shape as :meth:`list_mcp_servers`,
        so both can be consumed identically. Each entry additionally carries
        ``operational_urls`` with the live endpoint(s).

        Unlike :meth:`list_mcp_servers` this always requires a valid token: the
        answer is account-private, so there is no anonymous view to fall back on.

        Examples
        --------
        >>> page = api.list_operational_mcp_servers()
        >>> [s["id"] for s in page.items]
        ['alice/weather-mcp', ...]
        """
        payload = self.openapi.list_operational_mcp_servers()
        items, total, page, size = self._extract_paged(payload)
        return PagedResult(items=list(items), total_count=total, page_number=page, page_size=size)

    def get_mcp_server(
        self,
        server_id: str,
        *,
        get_operational_url: bool | None = None,
    ) -> dict:
        """Fetch a single MCP server's metadata.

        Parameters
        ----------
        server_id : str
            MCP server identifier.
        get_operational_url : bool, optional
            When ``True``, the response includes the live runtime URL.

        Returns
        -------
        dict
            MCP server metadata.

        Examples
        --------
        >>> info = api.get_mcp_server("alice/weather-mcp", get_operational_url=True)
        >>> info["operational_url"]
        'https://...'
        """
        return self.openapi.get_mcp_server(server_id, get_operational_url=get_operational_url)

    def deploy_mcp_server(self, server_id: str, *, payload: Mapping[str, Any] | None = None) -> dict:
        """Deploy or redeploy an MCP server.

        Examples
        --------
        >>> api.deploy_mcp_server("alice/weather-mcp", payload={"region": "cn-hangzhou"})
        """
        return self.openapi.deploy_mcp_server(server_id, payload)

    def undeploy_mcp_server(self, server_id: str) -> dict:
        """Undeploy a running MCP server.

        Examples
        --------
        >>> api.undeploy_mcp_server("alice/weather-mcp")
        """
        return self.openapi.undeploy_mcp_server(server_id)

    # ==================================================================
    # Agent-IDP
    # ==================================================================
    def create_agent_identity(self, payload: Mapping[str, Any]) -> AgentIdentity:
        """Register an Agent-IDP identity with an Ed25519 public JWK."""
        return AgentIdentity.from_dict(self.openapi.create_agent_identity(payload))

    def get_agent_identity(self, agent_id: str) -> AgentIdentity:
        """Return an Agent-IDP identity and its current public key."""
        return AgentIdentity.from_dict(self.openapi.get_agent_identity(agent_id))

    def update_agent_identity(self, agent_id: str, payload: Mapping[str, Any]) -> AgentIdentity:
        """Update an Agent-IDP identity's mutable metadata."""
        return AgentIdentity.from_dict(self.openapi.update_agent_identity(agent_id, payload))

    def delete_agent_identity(self, agent_id: str) -> dict:
        """Delete an Agent-IDP identity and prevent future token issuance."""
        result = self.openapi.delete_agent_identity(agent_id)
        return result if isinstance(result, dict) else {}

    def reset_agent_key_pair(self, agent_id: str, payload: Mapping[str, Any]) -> AgentIdentity:
        """Replace an Agent-IDP identity's registered Ed25519 public key."""
        return AgentIdentity.from_dict(self.openapi.reset_agent_key_pair(agent_id, payload))

    def pause_agent(self, agent_id: str, *, paused: bool) -> dict:
        """Pause or resume JWT issuance for an Agent-IDP identity."""
        result = self.openapi.pause_agent(agent_id, {"paused": paused})
        return result if isinstance(result, dict) else {}

    def list_agent_token_records(
        self,
        agent_id: str,
        *,
        page: int = 1,
        page_size: int = 20,
    ) -> PagedResult[AgentTokenRecord]:
        """List one Agent-IDP identity's issued token records."""
        payload = self.openapi.list_agent_token_records(agent_id, page=page, page_size=page_size)
        data = payload if isinstance(payload, Mapping) else {}
        raw_records = data.get("token_records")
        records: list[Any] = raw_records if isinstance(raw_records, list) else []
        return PagedResult(
            items=[AgentTokenRecord.from_dict(item) for item in records if isinstance(item, Mapping)],
            total_count=int(data.get("total_count") or 0),
            page_number=int(data.get("page_number") or page),
            page_size=int(data.get("page_size") or page_size),
            collection_key="token_records",
        )

    def list_user_agent_identities(
        self,
        username: str,
        *,
        status: str | None = None,
        page: int = 1,
        page_size: int = 20,
    ) -> PagedResult[AgentIdentitySummary]:
        """List a user's Agent-IDP identities via the OpenAPI surface."""
        payload = self.openapi.list_user_agent_identities(username, status=status, page=page, page_size=page_size)
        data = payload if isinstance(payload, Mapping) else {}
        raw_identities = data.get("agent_identities")
        identities: list[Any] = raw_identities if isinstance(raw_identities, list) else []
        return PagedResult(
            items=[AgentIdentitySummary.from_dict(item) for item in identities if isinstance(item, Mapping)],
            total_count=int(data.get("total_count") or 0),
            page_number=int(data.get("page_number") or page),
            page_size=int(data.get("page_size") or page_size),
            collection_key="agent_identities",
        )

    def issue_agent_token(self, payload: Mapping[str, Any]) -> AgentToken:
        """Exchange a locally signed Agent-IDP request for a short-lived JWT."""
        return AgentToken.from_dict(self.openapi.issue_agent_token(payload))

    def issue_agent_token_with_private_key(
        self,
        private_jwk: AgentJWK | Mapping[str, Any],
        *,
        agent_id: str,
        audience: str,
        timestamp: int | None = None,
    ) -> AgentToken:
        """Locally sign and exchange an Agent-IDP token request without persisting a key."""
        signed = sign_agent_token_request(
            private_jwk,
            agent_id=agent_id,
            audience=audience,
            timestamp=int(time.time()) if timestamp is None else timestamp,
        )
        return self.issue_agent_token(signed)

    def get_agent_id_configuration(self) -> AgentIdConfiguration:
        """Fetch anonymous Agent-IDP OIDC discovery metadata."""
        return AgentIdConfiguration.from_dict(self.openapi.get_agent_id_configuration())

    def get_agent_id_jwks(self) -> list[AgentJWK]:
        """Fetch anonymous Agent-IDP JWT verification keys."""
        payload = self.openapi.get_agent_id_jwks()
        keys = payload.get("keys") if isinstance(payload, Mapping) else None
        if not isinstance(keys, list):
            return []
        return [AgentJWK.from_dict(item) for item in keys if isinstance(item, Mapping)]

    # ==================================================================
    # Cache
    # ==================================================================
    def verify_cache(
        self,
        repo_id: str,
        repo_type: RepoTypeLike = "model",
        *,
        revision: str | None = None,
        cache_dir: str | Path | None = None,
        local_dir: str | Path | None = None,
    ) -> CacheVerification:
        """Verify local repository files against SHA-256 checksums from the Hub."""
        if cache_dir is not None and local_dir is not None:
            raise InvalidParameter("cache_dir and local_dir are mutually exclusive")
        rt = self._normalize_repo_type(repo_type)
        _, resolved_revision = _resolve_verification_root(
            repo_id,
            str(rt),
            revision=revision,
            cache_dir=cache_dir,
            local_dir=local_dir,
        )
        files = self.list_repo_files(repo_id, rt, revision=resolved_revision, recursive=True)
        expected = {file.path: file.sha256 for file in files if not file.is_dir and file.path}
        return _verify_cache(
            repo_id,
            str(rt),
            expected,
            revision=resolved_revision,
            cache_dir=Path(cache_dir) if cache_dir else None,
            local_dir=Path(local_dir) if local_dir else None,
        )

    def scan_cache(self, cache_dir: str | Path | None = None) -> CacheInfo:
        """Inspect the local cache directory.

        Parameters
        ----------
        cache_dir : str or Path, optional
            Override the default cache root.

        Returns
        -------
        CacheInfo
            Aggregated cache stats (total bytes, repo entries, ...).

        Examples
        --------
        >>> info = api.scan_cache()
        >>> info.size_on_disk
        12345678
        >>> [r.repo_id for r in info.repos][:3]
        ['alice/llama-7b', 'bob/imagenet', 'carol/whisper-base']
        """
        return _scan_cache(Path(cache_dir) if cache_dir else None)

    def clear_cache(
        self,
        *,
        cache_dir: str | Path | None = None,
        repo_type: RepoTypeLike | None = None,
        repo_id: str | None = None,
    ) -> int:
        """Remove cached data and return the number of bytes freed.

        Parameters
        ----------
        cache_dir : str or Path, optional
            Override the default cache root.
        repo_type : str or RepoType, optional
            Restrict deletion to a single repository type.
        repo_id : str, optional
            Restrict deletion to a single repository id.

        Returns
        -------
        int
            Number of bytes reclaimed from disk.

        Examples
        --------
        Wipe the cache for a single model:

        >>> api.clear_cache(repo_type="model", repo_id="alice/llama-7b")
        4823412

        Wipe everything:

        >>> api.clear_cache()
        """
        rt_value: str | None = None
        if repo_type is not None:
            rt_value = str(self._normalize_repo_type(repo_type))
        return _clear_cache(
            cache_dir=cache_dir if cache_dir is not None else self._config.cache_dir,
            repo_type=rt_value,
            repo_id=repo_id,
        )
